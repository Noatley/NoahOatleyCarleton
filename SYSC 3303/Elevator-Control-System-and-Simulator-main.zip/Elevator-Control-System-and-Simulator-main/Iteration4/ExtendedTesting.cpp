/**
 * ExtendedTesting.cpp
 * This file contains the test cases for the Elevator System.
 * @author Ryan Page, Kael Lascelle
 * @version 1.0
 */

#include <iostream>
#include <cassert>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <queue>
#include <vector>
#include <chrono>
#include <thread>
#include <algorithm>
#include "ElevatorSubsystem.cpp"
#include "ElevatorStatemachine.cpp"
#include "SchedulerSystem.cpp"
#include "SchedulerStatemachine.cpp"
#include "FloorSubsystem.cpp"
#include "Globals.cpp"
#include "InetHelpers.cpp"

// ==============================
// Test 1: ElevatorSubsystem Initialization
// ==============================
bool testElevatorSubsystemInitialization()
{
    ElevatorSubsystem elevatorSubsystem1(ELEVATOR1PORT);
    assert(elevatorSubsystem1.getCurrentFloor() == 1);
    assert(elevatorSubsystem1.getCompletedFloors().size() != 1);
    assert(elevatorSubsystem1.getDownQueue().size() == 0);
    assert(elevatorSubsystem1.getUpQueue().size() == 0);
    assert(elevatorSubsystem1.elevatorContext.getQueueSize() == 0);
    assert(elevatorSubsystem1.elevatorContext.getState() == ElevatorStates::STATIONARY);
    assert(elevatorSubsystem1.elevatorContext.getStatus() == false);

    ElevatorSubsystem elevatorSubsystem2(ELEVATOR2PORT);
    assert(elevatorSubsystem2.getCurrentFloor() == 1);
    assert(elevatorSubsystem2.getCompletedFloors().size() != 1);
    assert(elevatorSubsystem2.getDownQueue().size() == 0);
    assert(elevatorSubsystem2.getUpQueue().size() == 0);
    assert(elevatorSubsystem2.elevatorContext.getQueueSize() == 0);
    assert(elevatorSubsystem2.elevatorContext.getState() == ElevatorStates::STATIONARY);
    assert(elevatorSubsystem2.elevatorContext.getStatus() == false);

    ElevatorSubsystem elevatorSubsystem3(ELEVATOR4PORT);
    assert(elevatorSubsystem3.getCurrentFloor() == 1);
    assert(elevatorSubsystem3.getCompletedFloors().size() != 1);
    assert(elevatorSubsystem3.getDownQueue().size() == 0);
    assert(elevatorSubsystem3.getUpQueue().size() == 0);
    assert(elevatorSubsystem3.elevatorContext.getQueueSize() == 0);
    assert(elevatorSubsystem3.elevatorContext.getState() == ElevatorStates::STATIONARY);
    assert(elevatorSubsystem3.elevatorContext.getStatus() == false);

    ElevatorSubsystem elevatorSubsystem4(SCHEDULERPORT + 4);
    assert(elevatorSubsystem4.getCurrentFloor() == 1);
    assert(elevatorSubsystem4.getCompletedFloors().size() != 1);
    assert(elevatorSubsystem4.getDownQueue().size() == 0);
    assert(elevatorSubsystem4.getUpQueue().size() == 0);
    assert(elevatorSubsystem4.elevatorContext.getQueueSize() == 0);
    assert(elevatorSubsystem4.elevatorContext.getState() == ElevatorStates::STATIONARY);
    assert(elevatorSubsystem4.elevatorContext.getStatus() == false);

    return true;
}

// ==============================
// Test 2: ElevatorStatemachine Transition Test
// This test uses the actual ElevatorContext functions.
// ==============================
bool testElevatorStatemachineTransition()
{
    // Create an ElevatorContext instance.
    ElevatorContext ec;

    // Initially, the elevator should be in the STATIONARY state.
    assert(ec.getState() == ElevatorStates::STATIONARY && "Initial state should be STATIONARY");

    // Create a dummy packet request. For example, a request from floor 1 to floor 15.
    std::vector<int> dummyRequest = {1, 15};
    ec.addPacketRequest(dummyRequest);

    // Call performAction once. In STATIONARY state with a pending request,
    // handleStationary() should set the state to MOVING.
    ec.performAction();
    assert(ec.getState() == ElevatorStates::MOVING && "After performAction in STATIONARY, state should be MOVING");

    // Call performAction again. In the MOVING state, handleMoving() will simulate travel time
    // (sleeping for 2 seconds) then change the state to ARRIVED.
    ec.performAction();
    assert(ec.getState() == ElevatorStates::ARRIVED && "After performAction in MOVING, state should be ARRIVED");

    // Call performAction a final time. In the ARRIVED state, handleArrived() will set the 'ready'
    // flag to true and then transition back to STATIONARY (if the queue is empty).
    ec.performAction();
    assert(ec.getStatus() == true && "After performAction in ARRIVED, elevator should be ready");
    assert(ec.getState() == ElevatorStates::STATIONARY && "After handling ARRIVED, state should revert to STATIONARY");

    return true;
}

// ==============================
// Test 3: FloorSubsystem Valid Processing Test
// This test creates a temporary file with a valid floor request, verifies that the inputs
// queue is populated by parseFile, and then that sendToScheduler() processes the request.
// ==============================
bool testFloorSubsystemValidProcessing()
{
    const std::string validFilename = "temp_valid_floor_input.txt";
    {
        std::ofstream ofs(validFilename);
        assert(ofs.is_open() && "Unable to open temporary file for valid input test");
        // Valid format: <time> <current floor> <direction> <destination floor>
        ofs << "00:00:05.000 1 Up 5" << std::endl;
    }

    // Instantiate FloorSubsystem with the valid input file.
    FloorSubsystem fs(validFilename);

    // Retrieve the inputs priority queue.
    auto inputs = fs.getInputs();
    assert(!inputs.empty() && "Inputs queue should not be empty for valid input file");

    // Call sendToScheduler, which should process (send and pop) the top request.
    bool sent = fs.sendToScheduler();
    assert(sent && "sendToScheduler should return true when a request is processed");

    // After processing one input, the inputs queue should be empty for this test case.
    auto inputsAfter = fs.getInputs();
    assert(inputsAfter.empty() && "Inputs queue should be empty after processing the request");

    std::remove(validFilename.c_str());
    return true;
}

// ==============================
// Test 4: FloorSubsystem Invalid Input Test
// This test creates a temporary file with an invalid floor request and verifies that
// the FloorSubsystem detects the invalid input.
// ==============================
bool testFloorSubsystemInvalidInput()
{
    const std::string invalidFilename = "temp_invalid_floor_input.txt";
    {
        std::ofstream ofs(invalidFilename);
        assert(ofs.is_open() && "Unable to open temporary file for invalid input test");
        // Using an invalid current floor (0) assuming floors start at 1.
        ofs << "00:00:05.000 0 Up 5" << std::endl;
    }

    FloorSubsystem fs(invalidFilename);
    assert(fs.getInvalidInput() && "FloorSubsystem should detect invalid input");

    std::remove(invalidFilename.c_str());
    return true;
}

// ==============================
// Test 5: Input File Test - Going to Invalid Floor (test1.txt)
// ==============================
bool testGoingToInvalidFloor_FromInputFile_1()
{
    FloorSubsystem floorSubsystem1("test1.txt");
    assert(floorSubsystem1.getInvalidInput() == true);
    return true;
}

// ==============================
// Test 6: Input File Test - Going to Invalid Floor (test2.txt)
// ==============================
bool testGoingToInvalidFloor_FromInputFile_2()
{
    FloorSubsystem floorSubsystem2("test2.txt");
    assert(floorSubsystem2.getInvalidInput() == true);
    return true;
}

// ==============================
// Test 7: Input File Test - Going to Invalid Floor (test5.txt)
// ==============================
bool testGoingToInvalidFloor_FromInputFile_3()
{
    FloorSubsystem floorSubsystem3("test5.txt");
    assert(floorSubsystem3.getInvalidInput() == true);
    return true;
}

// ==============================
// Test 8: Input File Test - Going to Invalid Floor (test6.txt)
// ==============================
bool testGoingToInvalidFloor_FromInputFile_4()
{
    FloorSubsystem floorSubsystem4("test6.txt");
    assert(floorSubsystem4.getInvalidInput() == true);
    return true;
}

// ==============================
// Test 9: Integrated Scheduler-Floor-Elevator Test
// This test runs parts of the system together. Modify as needed if it causes blocking.
// ==============================
bool Testing_System()
{
    FloorSubsystem floorSubsystem("test3.txt");
    SchedulerSystem schedulerSystem;
    ElevatorSubsystem elevatorSubsystem1(ELEVATOR1PORT);
    ElevatorSubsystem elevatorSubsystem2(ELEVATOR2PORT);
    ElevatorSubsystem elevatorSubsystem3(ELEVATOR3PORT);
    ElevatorSubsystem elevatorSubsystem4(ELEVATOR4PORT);
    floorSubsystem.sendToScheduler();
    schedulerSystem.takeRequests();
    // schedulerSystem.scheduleRequests(); // This may block depending on the internal loop
    return true;
}

// ==============================
// Main: Run All Tests
// ==============================
int main()
{
    // Set Testing flag as needed
    Testing = 1; // True testing mode

    bool test1 = testElevatorSubsystemInitialization();
    bool test2 = testElevatorStatemachineTransition();
    bool test3 = testFloorSubsystemValidProcessing();
    bool test4 = testFloorSubsystemInvalidInput();
    bool test5 = testGoingToInvalidFloor_FromInputFile_1();
    bool test6 = testGoingToInvalidFloor_FromInputFile_2();
    bool test7 = testGoingToInvalidFloor_FromInputFile_3();
    bool test8 = testGoingToInvalidFloor_FromInputFile_4();
    bool test9 = Testing_System();

    std::cout << "_______________________________________________________________\n\n";
    std::cout << "Elevator System Testing (1 = Passed, 0 = Failed)" << std::endl;
    std::cout << "_______________________________________________________________\n";
    std::cout << "Test 1: ElevatorSubsystem Initialization: " << test1 << std::endl;
    std::cout << "Test 2: ElevatorStatemachine Transition: " << test2 << std::endl;
    std::cout << "Test 3: FloorSubsystem Valid Processing: " << test3 << std::endl;
    std::cout << "Test 4: FloorSubsystem Invalid Input: " << test4 << std::endl;
    std::cout << "Test 5: Input File Test - Going to Invalid Floor (test1.txt): " << test5 << std::endl;
    std::cout << "Test 6: Input File Test - Going to Invalid Floor (test2.txt): " << test6 << std::endl;
    std::cout << "Test 7: Input File Test - Going to Invalid Floor (test5.txt): " << test7 << std::endl;
    std::cout << "Test 8: Input File Test - Going to Invalid Floor (test6.txt): " << test8 << std::endl;
    std::cout << "Test 9: Integrated Scheduler-Floor-Elevator Test: " << test9 << std::endl;

    bool allTestsPassed = test1 && test2 && test3 && test4 && test5 && test6 && test7 && test8 && test9;

    std::cout << "\nOverall Test Results: "
              << (allTestsPassed ? "All Tests Passed" : "Some Tests Failed")
              << "\n";
    std::cout << "_______________________________________________________________\n";
    return 0;
}
