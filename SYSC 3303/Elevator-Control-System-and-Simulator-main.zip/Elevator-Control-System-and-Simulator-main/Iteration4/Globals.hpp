#ifndef GLOBALS_HPP
#define GLOBALS_HPP

#include <queue>
#include <set>
#include <mutex>
#include <condition_variable>
#include <assert.h>
#include <algorithm>
#include "ElevatorSystem.hpp" // Include the main header for struct definitions
#include "Datagram.hpp"
#include "InetHelpers.hpp"

#define FLOORPORT 17399 //port that the floor will use to receive from the scheduler
#define OPENPORT 17398


#define SCHEDULERFLOORPORT 17395 //port that the scheduler will use to receive from floor

#define SCHEDULER1PORT 17401 //ports that scheduler will monitor to receive from elevator
#define SCHEDULER2PORT 17402
#define SCHEDULER3PORT 17403
#define SCHEDULER4PORT 17404

#define SCHEDULERPORT 17410 //may not be needed

#define ELEVATOR1PORT 17425 //ports that elevators will use to receive from scheduler
#define ELEVATOR2PORT 17426
#define ELEVATOR3PORT 17427
#define ELEVATOR4PORT 17428

#define MAXELEVATORS 4
#define MAXPACKETLENGTH 50
#define MAXFLOORS 22
#define OFFSET 17424 //offset for finding elevator ports (usually port 1 - 1)
#define SCHEDULEROFFSET 17400 //offset for elevators sending to scheduler


// Declare global variables
extern std::queue<struct RequestStructure> requests; // Requests from floor to scheduler
extern std::queue<struct RequestStructure> elevatorQueue; // Requests from scheduler to elevator
extern std::set<int> pickups; // Elevator notifies scheduler of completed floors
extern std::set<int> finishedFloors; // Scheduler notifies floor to empty its queue

// Declare global mutexes and condition variables
extern std::mutex schedulerLock;
extern std::condition_variable_any cond;
extern std::mutex elevatorLock;
extern std::condition_variable_any eleCond;
extern std::mutex pickLock;
extern std::condition_variable pickCond;

extern int Testing;

#endif