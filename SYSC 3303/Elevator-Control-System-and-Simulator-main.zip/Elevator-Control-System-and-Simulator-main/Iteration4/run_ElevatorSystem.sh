#!/bin/bash

# Remove old executables
rm -f FloorSubsystem ElevatorSubsystem SchedulerSystem

# Compile the C++ files with pthread support
g++ -c Globals.cpp -o Globals.o
g++ -c InetHelpers.cpp -o InetHelpers.o
g++ -c SchedulerStatemachine.cpp -o SchedulerStatemachine.o
g++ -c ElevatorStatemachine.cpp -o ElevatorStatemachine.o

g++ -o SchedulerSystem startScheduler.cpp SchedulerSystem.cpp Globals.o InetHelpers.o SchedulerStatemachine.o
g++ -o ElevatorSubsystem startElevator.cpp ElevatorSubsystem.cpp Globals.o InetHelpers.o ElevatorStatemachine.o
g++ -o FloorSubsystem startFloor.cpp FloorSubsystem.cpp Globals.o InetHelpers.o 

xterm -hold -e "./ElevatorSubsystem" &
xterm -hold -e "./SchedulerSystem" &
sleep 0.1
xterm -hold -e "./FloorSubsystem" &