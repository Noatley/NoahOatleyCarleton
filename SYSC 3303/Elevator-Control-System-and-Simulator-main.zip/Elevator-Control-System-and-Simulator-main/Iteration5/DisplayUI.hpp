#ifndef DISPLAYUI_HPP
#define DISPLAYUI_HPP

#include <ncurses.h>
#include <chrono>
#include <thread>
#include "Globals.hpp"

void initialize_ncurses();

void display_subsystem_status(sharedData* shared);

#endif