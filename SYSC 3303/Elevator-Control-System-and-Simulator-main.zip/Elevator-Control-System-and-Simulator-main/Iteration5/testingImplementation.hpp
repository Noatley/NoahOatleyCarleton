#include <iostream>
#include <thread>
#include <chrono>

#include "assert.h"



inline void testUI() {
    std::cout << "Testing UI display" << std::endl;
    std::cout << "Testing FloorStatus" << std::endl;
    std::cout << "Testing SchedulerStatus" << std::endl;
    std::cout << "Testing ElevatorStatuses" << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(3));
    std::cout << "All tests passed" << std::endl;
}

