#include "DisplayUI.hpp"

int main() {
    initialize_ncurses();
    SharedMemoryManager shm;
    sharedData* shared = shm.get();
    
    while (true) {
        clear();
        
        // Lock mutex before reading shared data
        
        display_subsystem_status(shared);
        
        // Unlock mutex after reading
        
        refresh(); 
        std::this_thread::sleep_for(std::chrono::milliseconds(200)); // Refresh rate
    }
    
    endwin();
    return 0;
}