#include "SchedulerSystem.hpp"
#include "SchedulerStatemachine.hpp"

SchedulerSystem::SchedulerSystem() : receiveFloorSocket(SCHEDULERFLOORPORT), receiveElevatorSocket1(SCHEDULER1PORT), receiveElevatorSocket2(SCHEDULER2PORT), receiveElevatorSocket3(SCHEDULER3PORT), receiveElevatorSocket4(SCHEDULER4PORT), operationalElevators({true, true, true, true}), elevatorsResponded(), schedulerStatus("Operational") {
    for (int i = 0; i < 4; i++) {
        std::vector<uint8_t> temp;
        elevatorStatuses.push_back(temp);
        elevatorsResponded.push_back(false);
    }
    Testing = 1;

    SharedMemoryManager shm;
    shared = shm.get();
}
//FLOOR->SCHEDULER
void SchedulerSystem::takeRequests() {
    schedulerContext.setSchedulerState(SchedulerStates::LISTENING);
    //CHANGES STARTED HERE
    //Note: If you receive an error "socket bind failedAddress already in use" when running the program, it is because the port is already in use.
    //To fix this: Open a new terminal and run again. If that doesnt work restart VsCode. 
    //Best to implement a way to close sockets/ports before the program restarts or when that error is thrown. A destructor is included in Datagram.hpp line 86.
    
    std::vector<uint8_t> received = receiveFromSubsystem(receiveFloorSocket);

    if(received[0]==0) { // Check if message is from a Floor
        if(0 < received[1] < 23) { // Check if floor is valid
            if(received[2] == 0) { // Check if message is a destination request
                if(received[1] != received[3]) { // Check if floor requested is not origin floor 
                    // Make request structure and add to queue
                    struct RequestStructure request = RequestStructure(std::chrono::milliseconds(0), received[1], received[3], (received[1]<received[3]), received[4], received[5]);
                    std::cout << "[SCHEDULER]: Received request from floor: Origin Floor: " << static_cast<int>(received[1]) << ". Destination Floor: " << static_cast<int>(received[3]) << std::endl;
                    RequestedFloors.push(request);
                }
    //CHANGES ENDED HERE
            }
        }
        else {
            std::cout << "[SCHEDULER]: Invalid floor packet received." << std::endl;
        }
    }

    std::vector<uint8_t> nextData;
    nextData.push_back(0);
    nextData.push_back(0);
    nextData.push_back(3);
    nextData.push_back(0);

    sendToSubsystem(FLOORPORT, nextData);
}

void SchedulerSystem::runFloorListener() {
    while(true) {
        takeRequests();

    }
}

void SchedulerSystem::scheduleRequests() {
    schedulerContext.setSchedulerState(SchedulerStates::SCHEDULING);
    while (!RequestedFloors.empty()) {
        schedulerContext.setSchedulerState(SchedulerStates::SCHEDULING);
        RequestStructure request = RequestedFloors.front();
        RequestedFloors.pop(); // Temporarily remove request from queue
        int bestElevatorIndex = -1;
        int bestDistance = MAXFLOORS + 1;  // Assume MAXFLOORS is defined appropriately
        int bestCapacity = 200;            // Assume max elevator capacity is 200

        // Reset elevator responses and ping all elevators
        std::fill(elevatorsResponded.begin(), elevatorsResponded.end(), false);
        pingElevators();


        ///gets stuck here 


        
        // Wait until all elevators have responded
        while (!std::all_of(elevatorsResponded.begin(), elevatorsResponded.end(), [](bool v) { return v; })) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            //pingElevators();
        }
        bool foundMatchingDirection = false;  // Track if any elevator was found moving in the correct direction

        // **Step 1: Try to find an elevator moving in the correct direction with lowest capacity**
        for (size_t i = 0; i < elevatorStatuses.size(); i++) {
            const auto& status = elevatorStatuses[i];
            bool elevatorDirection = (status[0] == 1);  // True for up, False for down
            int elevatorFloor = status[1];
            int elevatorCapacity = status[2];
            if(operationalElevators[i] == true) {
                if (request.direction == elevatorDirection) {
                    int distance = abs(request.originFloor - elevatorFloor);

                    // Check if the elevator is below (for UP requests) or above (for DOWN requests)
                    bool isOnTheWay = (request.direction && elevatorFloor < request.originFloor) ||
                                    (!request.direction && elevatorFloor > request.originFloor);

                    if (isOnTheWay) {
                        foundMatchingDirection = true;

                        // Prioritize lowest capacity first, then shortest distance
                        if (elevatorCapacity < bestCapacity || 
                            (elevatorCapacity == bestCapacity && distance < bestDistance)) {
                            bestCapacity = elevatorCapacity;
                            bestDistance = distance;
                            bestElevatorIndex = i;
                        }
                    }
                }
            }
            
        }

        // **Step 2: If no elevator is moving in the correct direction, pick the lowest capacity one**
        if (!foundMatchingDirection) {
            for (size_t i = 0; i < elevatorStatuses.size(); i++) {
                const auto& status = elevatorStatuses[i];
                int elevatorFloor = status[1];
                int elevatorCapacity = status[2];
                int distance = abs(request.originFloor - elevatorFloor);

                // Pick the elevator with the lowest capacity
                if(operationalElevators[i] == true) {
                    if (elevatorCapacity < bestCapacity || 
                        (elevatorCapacity == bestCapacity && distance < bestDistance)) {
                        bestCapacity = elevatorCapacity;
                        bestDistance = distance;
                        bestElevatorIndex = i;
                    }
                }
            }
        }

        // **Step 3: If still no elevator was found, re-add the request to be processed later**
        if (bestElevatorIndex == -1) {
            RequestedFloors.push(request);
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            continue;
        }

        schedulerContext.setSchedulerState(SchedulerStates::TRANSMITTING);
        // **Build the message to send to the chosen elevator**
        std::vector<uint8_t> message;
        message.clear();
        message.push_back(1);                     // Identifier (for elevator subsystem)
        message.push_back(bestElevatorIndex + 1); // Elevator ID (assume IDs are 1-indexed)
        message.push_back(0);                     // Packet type (0 = floor request)
        message.push_back(request.originFloor);   // Origin floor from the request
        message.push_back(request.destination);   // Destination floor from the request
        message.push_back(request.error);         // Error type
        message.push_back(request.errorFloor);    // What floor the error happens on

        // Send request to elevator
        sendToSubsystem(OFFSET + message[1], message);
    }
}


//SCHEDULER->ELEVATOR
void SchedulerSystem::sendRequests_Testing() {
    schedulerContext.setSchedulerState(SchedulerStates::TRANSMITTING);
    schedulerContext.performAction();
    while (!scheduledRequests.empty()) {
        elevatorQueue.push(scheduledRequests.front());
        scheduledRequests.pop();
    }
}

//ELEVATOR->SCHEDULER
void SchedulerSystem::getCompleted_Testing() {
    schedulerContext.setSchedulerState(SchedulerStates::SCHEDULING);
    //schedulerContext.performAction();
    while (!pickups.empty()) {
        int value = *pickups.begin();
        completedFloors.insert(value);
        pickups.erase(value);
    }
}

//SCHEDULER->FLOOR
void SchedulerSystem::notifyFloors_Testing() {
    schedulerContext.setSchedulerState(SchedulerStates::OPENING);
    schedulerContext.performAction();
    while (!completedFloors.empty()) {
        int value = *completedFloors.begin();
        finishedFloors.insert(value);
        completedFloors.erase(value);
    }
}

void SchedulerSystem::runScheduler() {
    if(Testing == 0){
        takeRequests();
        scheduleRequests();
        runElevatorListener_Testing(receiveElevatorSocket1, ELEVATOR1PORT);
        runElevatorListener_Testing(receiveElevatorSocket2, ELEVATOR2PORT);
        runElevatorListener_Testing(receiveElevatorSocket3, ELEVATOR3PORT);
        runElevatorListener_Testing(receiveElevatorSocket4, ELEVATOR4PORT);

    }else{
        floorListenerThread = std::thread(&SchedulerSystem::runFloorListener, this);
        elevatorListenerThread1 = std::thread(&SchedulerSystem::runElevatorListener, this, receiveElevatorSocket1, ELEVATOR1PORT);
        elevatorListenerThread2 = std::thread(&SchedulerSystem::runElevatorListener, this, receiveElevatorSocket2, ELEVATOR2PORT);
        elevatorListenerThread3 = std::thread(&SchedulerSystem::runElevatorListener, this, receiveElevatorSocket3, ELEVATOR3PORT);
        elevatorListenerThread4 = std::thread(&SchedulerSystem::runElevatorListener, this, receiveElevatorSocket4, ELEVATOR4PORT);
        while (true) {
            scheduleRequests();
    
            std::this_thread::sleep_for(std::chrono::milliseconds(100)); 
        }
    }
}

void SchedulerSystem::pingElevators() {
    for(int i = 1; i<5; i++) { // For each elevator, create a message
        std::vector<uint8_t> pingMessage;
        pingMessage.push_back(1);
        pingMessage.push_back(i);
        pingMessage.push_back(3);
        sendToSubsystem(OFFSET + i, pingMessage);
    }
}

void SchedulerSystem::runElevatorListener(DatagramSocket socket, int port) {
    int id = port - OFFSET;
    while(true) {
        std::vector<uint8_t> received = receiveFromSubsystem(socket);
        if(received[2] == 4) {
            std::vector<uint8_t> elevatordata = {received[3], received[4], received[5]};
            elevatorStatuses[received[1]-1] = elevatordata;
            elevatorsResponded[received[1]-1] = true;
        }
        else if(received[2] == 1) { // If not a destination, check if its a notify
            if(0 < received[3] < 5) {
                schedulerContext.setSchedulerState(SchedulerStates::TRANSMITTING);
                // Create and send packet to floor to open doors
                std::vector<uint8_t> floorMessage;
                floorMessage.push_back(0);
                floorMessage.push_back(received[3]);
                floorMessage.push_back(2);
                floorMessage.push_back(0);
                sendToSubsystem(OPENPORT, floorMessage);

                // Create and send packet to elevator to open doors
                std::vector<uint8_t> elevatorMessage;
                elevatorMessage.push_back(1);
                elevatorMessage.push_back(received[1]);
                elevatorMessage.push_back(2);
                elevatorMessage.push_back(received[3]);
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                sendToSubsystem(port, elevatorMessage);
            }
        }
        else if (received[2] == 5){ // 5 is error
            if(received[3]==0) { // Error is not recoverable
                // Open door of what floor its on to let everyone off
                std::vector<uint8_t> floorMessage;
                floorMessage.push_back(0);
                floorMessage.push_back(received[4]);
                floorMessage.push_back(2);
                floorMessage.push_back(0);
                sendToSubsystem(OPENPORT, floorMessage);

                std::vector<uint8_t> elevatorMessage;
                elevatorMessage.push_back(1);
                elevatorMessage.push_back(received[1]);
                elevatorMessage.push_back(2);
                elevatorMessage.push_back(received[3]);
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                sendToSubsystem(port, elevatorMessage);

                operationalElevators[received[1]-1] = false;

                bool downReached = false;
                // Reschedule up queue
                for(int iterator = 6; iterator < received.size(); iterator++) {
                    if (received[iterator] == 0) {downReached = true; continue;}
                    RequestStructure newRequest(std::chrono::milliseconds(1), received[4], received[iterator], !downReached);
                    RequestedFloors.push(newRequest);
                }

            }
        }
        else {
            std::cout << "Invalid packet received from elevator " << id << std::endl;
            for (int i = 0; i < received.size(); i++) {
                std::cout << static_cast<int>(received[i]) << " ";
            }
            std::cout << std::endl;
        }
    }
}

//shared memory update
void SchedulerSystem::updateSchedulerStatus(sharedData* shared, const SchedulerStatus& new_status) {
    shared->schedulerStatus = new_status;
    shared->ready.store(true, std::memory_order_release);
}

void SchedulerSystem::schedulerUpdate() {

}



//getters
std::queue<struct RequestStructure> SchedulerSystem::getScheduledRequests () {
    return scheduledRequests;
}

std::queue<struct RequestStructure>  SchedulerSystem::getRequestedFloors () {
    return RequestedFloors;
}

std::set<int> SchedulerSystem::getCompletedFloors () {
    return completedFloors;
}

std::set<int> SchedulerSystem::getFinishedFloors () {
    return finishedFloors;
}

//setters
void SchedulerSystem::setScheduledRequests (std::queue<struct RequestStructure> sch) {
    scheduledRequests = sch;
}

void SchedulerSystem::setRequestedFloors (std::queue<struct RequestStructure> req) {
    RequestedFloors = req;
}

void SchedulerSystem::setCompletedFloors (std::set<int> com) {
    completedFloors = com;
}

void SchedulerSystem::runElevatorListener_Testing(DatagramSocket socket, int port) {
    int id = port - OFFSET;
    std::vector<uint8_t> received = receiveFromSubsystem(socket);
    if(received[2] == 4) {
        std::vector<uint8_t> elevatordata = {received[3], received[4], received[5]};
        elevatorStatuses[received[1]-1] = elevatordata;
        elevatorsResponded[received[1]-1] = true;
    }
    else if(received[2] == 1) { // If not a destination, check if its a notify
        if(0 < received[3] < 5) {
            schedulerContext.setSchedulerState(SchedulerStates::TRANSMITTING);
            // Create and send packet to floor to open doors
            std::vector<uint8_t> floorMessage;
            floorMessage.push_back(0);
            floorMessage.push_back(received[3]);
            floorMessage.push_back(2);
            floorMessage.push_back(0);
            sendToSubsystem(OPENPORT, floorMessage);

            // Create and send packet to elevator to open doors
            std::vector<uint8_t> elevatorMessage;
            elevatorMessage.push_back(1);
            elevatorMessage.push_back(received[1]);
            elevatorMessage.push_back(2);
            elevatorMessage.push_back(received[3]);
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            sendToSubsystem(port, elevatorMessage);
        }
    }
    else if (received[2] == 5){ // 5 is error
        if(received[3]==0) { // Error is not recoverable
            // Open door of what floor its on to let everyone off
            std::vector<uint8_t> floorMessage;
            floorMessage.push_back(0);
            floorMessage.push_back(received[4]);
            floorMessage.push_back(2);
            floorMessage.push_back(0);
            sendToSubsystem(OPENPORT, floorMessage);

            std::vector<uint8_t> elevatorMessage;
            elevatorMessage.push_back(1);
            elevatorMessage.push_back(received[1]);
            elevatorMessage.push_back(2);
            elevatorMessage.push_back(received[3]);
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            sendToSubsystem(port, elevatorMessage);

            operationalElevators[received[1]-1] = false;

            bool downReached = false;
            // Reschedule up queue
            for(int iterator = 6; iterator < received.size(); iterator++) {
                if (received[iterator] == 0) {downReached = true; continue;}
                RequestStructure newRequest(std::chrono::milliseconds(1), received[4], received[iterator], !downReached);
                RequestedFloors.push(newRequest);
            }

        }
    }
}
