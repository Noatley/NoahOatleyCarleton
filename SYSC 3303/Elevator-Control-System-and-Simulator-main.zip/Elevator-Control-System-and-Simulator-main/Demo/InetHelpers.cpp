#include "InetHelpers.hpp"

bool isPortAvailable(int port) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        return false;
    }

    int opt = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = INADDR_ANY;

    bool available = bind(sock, (struct sockaddr*)&addr, sizeof(addr)) >= 0;
    close(sock);
    return available;
}

void sendToSubsystem(int port, std::vector<uint8_t> &data) {
    DatagramSocket socket;
    DatagramPacket packet(data, data.size(), InetAddress::getLocalHost(), port);
    try {
        socket.send(packet);
    } catch (const std::runtime_error &e) {
        std::cerr << "Error sending data: " << port << ": " << e.what() << std::endl;
        exit(-1);
    }
}

std::vector<uint8_t> receiveFromSubsystem(DatagramSocket &receiveSocket) {
    std::vector<uint8_t> data(MAXPACKETLENGTH);
    DatagramPacket packet(data, data.size());
    try {
        receiveSocket.receive(packet); //blocking
    } catch (const std::runtime_error &e) {
        std::cerr << "Error receiving data: " << e.what() << std::endl;
        for (uint8_t item : data) {
            std::cout << item << std::endl;
        }
        exit(-1);
    }
    return data;
}