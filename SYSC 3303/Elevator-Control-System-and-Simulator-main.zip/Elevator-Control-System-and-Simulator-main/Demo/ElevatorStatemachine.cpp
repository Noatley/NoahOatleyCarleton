#include "ElevatorStatemachine.hpp"

ElevatorContext::ElevatorContext() : prevElevatorState(ElevatorStates::STATIONARY), currentElevatorState(ElevatorStates::STATIONARY), currentFloor(-1), destination(-1), direction(-1), ready(false){
    //Starts in STATIONARY state, and intializes attributes to -1 to represent default values.
}

void ElevatorContext::addPacketRequest (std::vector<int> data){
    requestQueue.push(data); //Push the packet into a queue of requested packets?
}

void ElevatorContext::setElevatorState(ElevatorStates nextState){
    currentElevatorState = nextState;
}

void ElevatorContext::setPrevElevatorState(ElevatorStates prevState){
    prevElevatorState = prevState;
}

ElevatorStates ElevatorContext::getCurrentElevatorState(){
    return currentElevatorState;
}

ElevatorStates ElevatorContext::getPrevElevatorState(){
    return prevElevatorState;
}

void ElevatorContext::performAction() {
    switch (currentElevatorState){
        case ElevatorStates::STATIONARY:
            handleStationary();
            break;
        case ElevatorStates::MOVING:
            handleMoving();
            break;
        case ElevatorStates::ARRIVED:
            handleArrived();
            break;
    }
}

void ElevatorContext::handleStationary(){
    //If something in queue, transition to state MOVING
    if(!requestQueue.empty() && prevElevatorState == ElevatorStates::ARRIVED){
        requestQueue.pop();
        if (requestQueue.empty()){
            currentElevatorState = ElevatorStates::STATIONARY;
        }
        currentElevatorState = ElevatorStates::MOVING;
    }

    else if (!requestQueue.empty()){
        currentElevatorState = ElevatorStates::MOVING;
    }

}
void ElevatorContext::handleMoving(){
    ready = false;
    std::this_thread::sleep_for(std::chrono::seconds(2)); //Simulate travel time
    currentElevatorState = ElevatorStates::ARRIVED;
}
void ElevatorContext::handleArrived(){
    ready = true;
    if (requestQueue.empty()){
        currentElevatorState = ElevatorStates::STATIONARY;
    }
    else{
        prevElevatorState = ElevatorStates::ARRIVED;
        currentElevatorState = ElevatorStates::STATIONARY;
    }
}

const int ElevatorContext::getQueueSize(){
    return requestQueue.size();
}

bool ElevatorContext::getStatus(){
    return ready;
}

ElevatorStates ElevatorContext::getState(){
    return currentElevatorState;
}

void ElevatorContext::setCurrentFloor(int floor) {
    currentFloor = floor;
}

void ElevatorContext::setDirection(int dir) {
    direction = dir;
}


