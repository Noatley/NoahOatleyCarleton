## Elevator-Control-System-and-Simulator
Term project for SYSC3303 Iteration 5:
- Andrew Rivera 101192264 
- Kyle Mathias 101266139
- Ryan Page 101268082
- Kael Lascelle 101269383
- Noah Oatley 101189707

## Cumulative Group Assignments
### UML Diagrams
Kael, Noah, Andrew

### Testing Code
Ryan, Kael and Noah

### ElevatorSystem Code
Schedulers - Noah, Kyle and Andrew

Elevators - Andrew, Kyle and Noah

Floors - Kyle, Noah and Andrew

### New Files for Iteration 5:

### Running the ElevatorSystem.cpp File
1. Press Ctrl + Alt + T to open the terminal.
2. Navigate to Your Project Directory (using cd) 
3. Make run_ElevatorSystem.sh Executable By typing this into the Terminal
    - chmod +x run_ElevatorSystem.sh
4. Run the File By writing this into the Terminal
    - ./run_ElevatorSystem.sh
5. If errors are raised indicating the the command was not found
    - Run this command: sudo apt-get install xterm
    - Then run ./run_ElevatorSystem.sh again.

### Running the Testing.cpp File
1. Press Ctrl + Alt + T to open the terminal.
2. Navigate to Your Project Directory (using cd) 
3. Make run_Testing.sh Executable By typing this into the Terminal
    - chmod +x run_Testing.sh
4. Run the File By writing this into the Terminal
    - ./run_Testing.sh
