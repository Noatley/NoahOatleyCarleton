#include "ElevatorSubsystem.hpp"
#include "Globals.hpp"

void runElevator1() {
    std::cout << "[ELEVATOR 1]: Moving from 1 to 2" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime)); //1314
    std::cout << "[ELEVATOR 1]: Elevator arrived at floor 2" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //4922
    std::cout << "[ELEVATOR 1]: Opening doors on floor 2" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //9736
    std::cout << "[ELEVATOR 1]: Closing doors on floor 2" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //13344

    std::cout << "[ELEVATOR 1]: Moving from 2 to 16" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime * 14)); //31740
    std::cout << "[ELEVATOR 1]: Elevator arrived at floor 16" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //35348
    std::cout << "[ELEVATOR 1]: Opening doors on floor 16" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //40162
    std::cout << "[ELEVATOR 1]: Closing doors on floor 16" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //43770

    std::this_thread::sleep_for(std::chrono::milliseconds(43230)); //waiting for next request, 87000

    std::cout << "[ELEVATOR 1]: Moving from 16 to 11" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime * 4)); //92256
    std::cout << "[ELEVATOR 1]: Elevator arrived at floor 11" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //95864
    std::cout << "[ELEVATOR 1]: Opening doors on floor 11" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime));  //100178
    std::cout << "[ELEVATOR 1]: Closing doors on floor 11" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //103786

    std::cout << "[ELEVATOR 1]: Moving from 11 to 16" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime * 4)); //109042
    std::cout << "[ELEVATOR 1]: Elevator arrived at floor 16" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //112650
    std::cout << "[ELEVATOR 1]: Opening doors on floor 16" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime));  // 117464
    std::cout << "[ELEVATOR 1]: Closing doors on floor 16" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //121072

}

void runElevator2() {
    std::this_thread::sleep_for(std::chrono::milliseconds(14000)); 
    std::cout << "[ELEVATOR 2]: Moving from 1 to 19" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime * 18)); //37652
    std::cout << "[ELEVATOR 2]: Elevator arrived at floor 19" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //41260
    std::cout << "[ELEVATOR 2]: Opening doors on floor 19" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //46074
    std::cout << "[ELEVATOR 2]: Closing doors on floor 19" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //49682

    std::this_thread::sleep_for(std::chrono::milliseconds(54318)); //waiting for next request, 104000

    std::cout << "[ELEVATOR 2]: Moving from 19 to 1" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime * 4)); //109256
    std::cout << "[ELEVATOR 2]: Elevator arrived at floor 14" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //115264
    std::cout << "[ELEVATOR 2]: Opening doors on floor 14" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); // 120078
    std::cout << "[ELEVATOR 2]: Closing doors on floor 14" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //123686

    std::cout << "[ELEVATOR 2]: Moving from 14 to 9" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime * 4)); //128942
    std::cout << "[ELEVATOR 2]: Elevator arrived at floor 9" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //132550
    std::cout << "[ELEVATOR 2]: Opening doors on floor 9" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //137364
    std::cout << "[ELEVATOR 2]: Closing doors on floor 9" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //140972

    std::cout << "[ELEVATOR 2]: Moving from 9 to 1" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime * 7)); //150170
    std::cout << "[ELEVATOR 2]: Elevator arrived at floor 1" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //153778
    std::cout << "[ELEVATOR 2]: Opening doors on floor 1" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //158592
    std::cout << "[ELEVATOR 2]: Closing doors on floor 1" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //162200

    std::cout << "[ELEVATOR 2]: Moving from 1 to 22" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime * 20)); //188480
    std::cout << "[ELEVATOR 2]: Elevator arrived at floor 22" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //191088
    std::cout << "[ELEVATOR 2]: Opening doors on floor 22" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); // 195902
    std::cout << "[ELEVATOR 2]: Closing doors on floor 22" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //199510
}

void runElevator3() {
    std::this_thread::sleep_for(std::chrono::milliseconds(49000)); 
    std::cout << "[ELEVATOR 3]: Moving from 1 to 17" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime * 16)); //70024
    std::cout << "[ELEVATOR 3]: Elevator arrived at floor 17" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //73632
    std::cout << "[ELEVATOR 3]: Opening doors on floor 17" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //78446
    std::cout << "[ELEVATOR 3]: Closing doors on floor 17" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //82054
    
    std::cout << "[ELEVATOR 3]: Moving from 17 to 2" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime * 14)); //100450
    std::cout << "[ELEVATOR 3]: Elevator arrived at floor 2" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //104058
    std::cout << "[ELEVATOR 3]: Encountered an error opening doors on floor 2. Moving to the next floor." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime)); //105372
    std::cout << "[ELEVATOR 3]: Elevator arrived at floor 1" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //108980
    std::cout << "[ELEVATOR 3]: Opening doors on floor 1" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //113794
    std::cout << "[ELEVATOR 3]: Closing doors on floor 1" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //117402

}

void runElevator4() {
    std::this_thread::sleep_for(std::chrono::milliseconds(82000)); 
    std::cout << "[ELEVATOR 4]: Moving from 1 to 17" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime * 16)); //103024
    std::cout << "[ELEVATOR 4]: Elevator arrived at floor 17" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //106632
    std::cout << "[ELEVATOR 4]: Opening doors on floor 17" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //111446
    std::cout << "[ELEVATOR 4]: Closing doors on floor 17" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //115054
    std::cout << "[ELEVATOR 4]: Moving from 17 to 3" <<  std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime * 2)); //119862
    std::cout << "[ELEVATOR 4]: Encountered an non recoverable error at floor 14" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //123470
    std::cout << "[ELEVATOR 4]: Opening doors on floor 14" << std::endl;
}


void startThreads() {
    std::thread elevator1(runElevator1);
    std::thread elevator2(runElevator2);
    std::thread elevator3(runElevator3);
    std::thread elevator4(runElevator4);

    elevator1.join();
    elevator2.join();
    elevator3.join();
    elevator4.join();
}


int main () {
    startThreads();
}