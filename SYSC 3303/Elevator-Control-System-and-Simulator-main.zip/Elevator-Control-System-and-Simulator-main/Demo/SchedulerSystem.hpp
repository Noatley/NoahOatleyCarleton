#ifndef SCHEDULER_SYSTEM_HPP
#define SCHEDULER_SYSTEM_HPP

#include "Globals.hpp"
#include "ElevatorSystem.hpp"
#include "SchedulerStatemachine.hpp"
#include "ElevatorSubsystem.hpp"
#include <algorithm>

class SchedulerSystem {
private:
    std::thread floorListenerThread;

    std::thread elevatorListenerThread1;
    std::thread elevatorListenerThread2;
    std::thread elevatorListenerThread3;
    std::thread elevatorListenerThread4;
    
    std::thread transmitter;
    std::queue<struct RequestStructure> RequestedFloors;
    std::set<int> completedFloors;
    std::queue<struct RequestStructure> scheduledRequests;
    std::vector<std::vector<uint8_t>> elevatorStatuses;
    std::vector<bool> elevatorsResponded;
    std::vector<bool> operationalElevators;

    DatagramSocket receiveFloorSocket;

    DatagramSocket receiveElevatorSocket1;
    DatagramSocket receiveElevatorSocket2;
    DatagramSocket receiveElevatorSocket3;
    DatagramSocket receiveElevatorSocket4;

    SchedulerStatus schedulerStatus;

    sharedData* shared;

public:
    SchedulerContext schedulerContext;
    SchedulerSystem();
    void takeRequests();
    void takeRequests_Testing();
    void scheduleRequests();
    void sendRequests_Testing();
    void getCompleted_Testing();
    void notifyFloors_Testing();
    void runScheduler();

    void runFloorListener();
    void runElevatorListener(DatagramSocket socket, int port);
    void runElevatorListener_Testing(DatagramSocket socket, int port);

    std::queue<struct RequestStructure> getScheduledRequests();
    std::queue<struct RequestStructure>  getRequestedFloors();
    std::set<int> getCompletedFloors();
    std::set<int> getFinishedFloors();
    void pingElevators();
    void setScheduledRequests(std::queue<struct RequestStructure> sch);
    void setRequestedFloors(std::queue<struct RequestStructure> req);
    void setCompletedFloors(std::set<int> com);
    void transmit(std::vector<uint8_t> received);
    void updateSchedulerStatus(sharedData* shared, const SchedulerStatus& new_status);
    void schedulerUpdate();
};

#endif