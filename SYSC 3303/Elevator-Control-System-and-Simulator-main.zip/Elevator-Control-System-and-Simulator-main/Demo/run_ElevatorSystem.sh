#!/bin/bash

pkill -f "FloorSubsystem|ElevatorSubsystem|SchedulerSystem|Monitor" || true
pkill -f "xterm -hold -e ./(FloorSubsystem|ElevatorSubsystem|SchedulerSystem|Monitor)" || true

# Remove old executables
rm -f FloorSubsystem ElevatorSubsystem SchedulerSystem Monitor DisplayUI
rm -f Globals.o InetHelpers.o SchedulerStatemachine.o ElevatorStatemachine.o sharedMemory.o
rm -f startScheduler startElevator startFloor

# Compile all components
g++ -c Globals.cpp -o Globals.o
g++ -c InetHelpers.cpp -o InetHelpers.o
g++ -c SchedulerStatemachine.cpp -o SchedulerStatemachine.o
g++ -c ElevatorStatemachine.cpp -o ElevatorStatemachine.o
g++ -c sharedMemory.cpp -o sharedMemory.o
g++ -c DisplayUI.cpp -o DisplayUI.o

g++ -o SchedulerSystem startScheduler.cpp SchedulerSystem.cpp Globals.o InetHelpers.o SchedulerStatemachine.o sharedMemory.o
g++ -o ElevatorSubsystem startElevator.cpp ElevatorSubsystem.cpp Globals.o InetHelpers.o ElevatorStatemachine.o sharedMemory.o
g++ -o FloorSubsystem startFloor.cpp FloorSubsystem.cpp Globals.o InetHelpers.o sharedMemory.o
g++ -o Monitor startMonitor.cpp DisplayUI.o Globals.o sharedMemory.o -lncurses

# Launch subsystems in separate terminals
xterm -hold -e "./ElevatorSubsystem" &
xterm -hold -e "./SchedulerSystem" &
xterm -hold -e "./FloorSubsystem" &
xterm -hold -e "./Monitor" &