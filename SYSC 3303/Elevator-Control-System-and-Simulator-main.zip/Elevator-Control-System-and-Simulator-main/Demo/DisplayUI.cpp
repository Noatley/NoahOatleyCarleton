#include "DisplayUI.hpp"
#include <cstring> // For strcmp

void initialize_ncurses() {
    initscr();
    cbreak();
    noecho();
    curs_set(0);
    start_color();
    
    // Initialize color pairs
    init_pair(1, COLOR_WHITE, COLOR_BLACK);   // Operational status
    init_pair(2, COLOR_YELLOW, COLOR_BLACK);  // Warning status
    init_pair(3, COLOR_RED, COLOR_BLACK);     // Error status
    init_pair(4, COLOR_BLUE, COLOR_BLACK);    // Elevator status
    init_pair(5, COLOR_GREEN, COLOR_BLACK); // Moving Status
    init_pair(6, COLOR_MAGENTA, COLOR_BLACK);   // Default status
}

void display_subsystem_status(sharedData* shared) {
    int row = 1;
    
    // Lock shared data for the entire display operation
    pthread_mutex_lock(&shared->mutex);
    
    // Elevator Status
    attron(COLOR_PAIR(1));
    mvprintw(row++, 1, "=========  ELEVATOR STATUS  =========");
    for (int i = 0; i < 4; i++) {
        const auto& elevator = shared->elevatorStatuses[i];
        
        // Choose color based on status
        if (strcmp(elevator.currentStatus, "Critical Error") == 0 || strcmp(elevator.currentStatus, "Error") == 0) {
            attron(COLOR_PAIR(3));
            mvprintw(row++, 1, "Elevator %d: Floor %d - %s", 
                elevator.elevatorID, 
                elevator.currentFloor, 
                elevator.currentStatus);
        } else if (strcmp(elevator.currentStatus, "Open") == 0) {
            attron(COLOR_PAIR(2));
            mvprintw(row++, 1, "Elevator %d: Floor %d - %s", 
                elevator.elevatorID, 
                elevator.currentFloor, 
                "Opening Doors");
        } else if (strncmp(elevator.currentStatus, "UP -", 4) == 0) {
            attron(COLOR_PAIR(5));
            mvprintw(row++, 1, "Elevator %d: Floor %d - %s", 
                elevator.elevatorID, 
                elevator.currentFloor, 
                elevator.currentStatus);
        }else if (strncmp(elevator.currentStatus, "DOWN -", 5) == 0) {
            attron(COLOR_PAIR(6));
            mvprintw(row++, 1, "Elevator %d: Floor %d - %s", 
                elevator.elevatorID, 
                elevator.currentFloor, 
                elevator.currentStatus);
        }else {
            attron(COLOR_PAIR(4));
            mvprintw(row++, 1, "Elevator %d: Floor %d - %s", 
                elevator.elevatorID, 
                elevator.currentFloor, 
                elevator.currentStatus);
        }
    }
    attron(COLOR_PAIR(1));
    mvprintw(row++, 1, "=====================================");
    // Unlock shared data
    pthread_mutex_unlock(&shared->mutex);
}

void display_elevator_movement(sharedData* shared) {
    const int numFloors = 22;
    const int elevatorWidth = 5;
    const int elevatorSpacing = 7;
    const int baseRow = 7; // Starting row for the elevator display

    // Lock shared data for the entire display operation
    pthread_mutex_lock(&shared->mutex);

    // Draw the elevator shafts
    for (int floor = numFloors; floor >= 1; --floor) {
        for (int i = 0; i < 5; ++i) {
            int col = 1 + i * elevatorSpacing;
            const auto& elevator = shared->elevatorStatuses[i-1];

            // Choose color based on status
            if (strcmp(elevator.currentStatus, "Critical Error") == 0 || strcmp(elevator.currentStatus, "Error") == 0) {
                attron(COLOR_PAIR(3));
            } else if (strcmp(elevator.currentStatus, "Open") == 0) {
                attron(COLOR_PAIR(2));
            } else if (strncmp(elevator.currentStatus, "UP -", 4) == 0) {
                attron(COLOR_PAIR(5));
            }else if (strncmp(elevator.currentStatus, "DOWN -", 5) == 0) {
                attron(COLOR_PAIR(6));
            }else {
                attron(COLOR_PAIR(4));
            }

            if(i == 0){
                attron(COLOR_PAIR(1));
                mvprintw(baseRow + (numFloors - floor), col, "Floor - %2d", floor);
                attroff(COLOR_PAIR(1));
            }else{
                attron(COLOR_PAIR(1)); // Set the color for the floor number
                mvprintw(baseRow + (numFloors - floor), col + 4, "|   |");
                attroff(COLOR_PAIR(1)); // Reset the color after printing
            }
        }
    }

    // Draw the elevators
    for (int i = 0; i < 5; ++i) {
        const auto& elevator = shared->elevatorStatuses[i-1];
        int col = 1 + i * elevatorSpacing;
        int row = baseRow + (numFloors - elevator.currentFloor);

        // Choose color based on status
        if (strcmp(elevator.currentStatus, "Critical Error") == 0 || strcmp(elevator.currentStatus, "Error") == 0) {
            attron(COLOR_PAIR(3));
        } else if (strcmp(elevator.currentStatus, "Open") == 0) {
            attron(COLOR_PAIR(2));
        } else if (strncmp(elevator.currentStatus, "UP -", 4) == 0) {
            attron(COLOR_PAIR(5));
        }else if (strncmp(elevator.currentStatus, "DOWN -", 5) == 0) {
            attron(COLOR_PAIR(6));
        }else {
            attron(COLOR_PAIR(4));
        }

        int floor_num;
        floor_num = elevator.currentFloor;
        if(i == 0){
            attron(COLOR_PAIR(1));
            mvprintw(row, col, "Floor - %2d", floor_num);
            attroff(COLOR_PAIR(1));
        }else{
            mvprintw(row, col + 4, "|[%d]|", elevator.elevatorID);
        }
        attroff(COLOR_PAIR(3) | COLOR_PAIR(2) | COLOR_PAIR(4)) | COLOR_PAIR(5);
    }
    attron(COLOR_PAIR(1));
    mvprintw(29, 1, "=====================================");
    // Unlock shared data
    pthread_mutex_unlock(&shared->mutex);
}