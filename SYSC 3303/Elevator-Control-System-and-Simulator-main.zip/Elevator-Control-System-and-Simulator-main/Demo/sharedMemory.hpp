#ifndef SHARED_MEMORY_H
#define SHARED_MEMORY_H

#include <sys/shm.h>
#include <sys/ipc.h>
#include <vector>
#include <string>
#include <atomic>
#include <pthread.h>

#include "Globals.hpp"

// Define a key for your shared memory segment
const key_t SHM_KEY = 0x1234;  // Can be any unique value

struct FloorStatus {
    char currentStatus[32]; // "Operational", etc.
    char floor[32][32]; // Array of status strings
    int count; // Number of active statuses

    FloorStatus(const char* status = "Operational") : count(0) {
        strncpy(currentStatus, status, sizeof(currentStatus));
        for (int i = 0; i < 32; ++i) {
            floor[i][0] = '\0'; 
        }
    }
};

struct SchedulerStatus {
    char currentStatus[32]; //also basically always operational
    char floor[32][32]; //example: ["7 Open", "5 Open"]
    int count; // Number of active statuses

    SchedulerStatus(const char* status = "Operational") : count(0) {
        strncpy(currentStatus, status, sizeof(currentStatus));
        for (int i = 0; i < 32; ++i) {
            floor[i][0] = '\0'; 
        }
    }
};

struct ElevatorStatus {
    int elevatorID;
    char currentStatus[32]; // "UP", "DOWN", "Stationary", "Open", "Critical Error"
    int currentFloor;

    ElevatorStatus(int id = 0, const char* status = "Stationary", int floor = 1) : 
        elevatorID(id), currentFloor(floor) {
        strncpy(currentStatus, status, sizeof(currentStatus));
    }
};

struct sharedData {
    std::atomic<bool> ready;
    pthread_mutex_t mutex;

    FloorStatus floorStatus;
    SchedulerStatus schedulerStatus;
    ElevatorStatus elevatorStatuses[4];

    sharedData() : 
        floorStatus("Operational"),
        schedulerStatus("Operational"),
        elevatorStatuses()  
    {
        pthread_mutexattr_t attr;
        pthread_mutexattr_init(&attr);
        pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED);
        pthread_mutex_init(&mutex, &attr);
        for (int i = 0; i < 4; ++i) {
            elevatorStatuses[i] = ElevatorStatus(i+1, "Stationary", 1);
        }
    }
};

class SharedMemoryManager {
public:
    SharedMemoryManager() {
        // Create shared memory segment
        shm_id = shmget(SHM_KEY, sizeof(sharedData), IPC_CREAT | 0666);
        if (shm_id == -1) {
            perror("shmget failed");
            exit(1);
        }

        // Attach to the segment
        data = static_cast<sharedData*>(shmat(shm_id, NULL, 0));
        if (data == (void*)-1) {
            perror("shmat failed");
            exit(1);
        }

        // Initialize if we're the first process
        static bool initialized = false;
        if (!initialized) {
            new (data) sharedData();  // Placement new
            initialized = true;
        }
    }

    sharedData* get() { return data; }

private:
    int shm_id;
    sharedData* data;
};

#endif