#ifndef ELEVATOR_SUBSYSTEM_HPP
#define ELEVATOR_SUBSYSTEM_HPP

#include "Globals.hpp"
#include "ElevatorStatemachine.hpp"

class ElevatorSubsystem {
private:
    std::set<int> upQueue;
    std::set<int> downQueue;
    std::set<int> completedFloors;
    std::vector<std::vector<int>> requirements; //so that if the elevator is moving towards the destination but hasnt gone to the origin yet, destination wont be chosen
    int currentFloor;
    int elevatorID;
    bool direction;
    int internal_port;
    int capacity;

    bool openResponse;
    bool pingResponse;
    bool error;
    bool recoverable;
    int errorSeverity;
    int errorFloor;

    bool operational;

    DatagramSocket elevatorSocket;
    std::thread listenerThread;
    std::thread sendThread;

    std::set<int> pickupQueue; 
    std::set<int> dropoffQueue; 



public:
    ElevatorContext elevatorContext;
    ElevatorSubsystem(int port);
    void sendToScheduler();
    void sendToScheduler_Testing();
    void createThreads();
    void receiveFromScheduler();
    void receiveFromScheduler_Testing();
    void runElevator();
    std::set<int> getUpQueue();
    std::set<int> getDownQueue();
    int getCurrentFloor() const;
    int getElevatorID() const;
    bool getDirection();
    std::set<int> getCompletedFloors();
    void setCompletedFloors(std::set<int> completed);
    void moveUp();
    void moveDown();
    void openDoors();
    void addRequirements(int originFloor, int destinationFloor);
    bool isOrigin(int floor);
    void moveOne();
    void updateElevatorStatus(sharedData* shared, const ElevatorStatus& new_status);
    void elevatorUpdate(bool open);
    void setCapacity(int cap);  
    int getCapacity();

private:
    void moveToFloor(int newFloor);

    ElevatorStatus elevatorStatus;

    sharedData* shared;
};

#endif