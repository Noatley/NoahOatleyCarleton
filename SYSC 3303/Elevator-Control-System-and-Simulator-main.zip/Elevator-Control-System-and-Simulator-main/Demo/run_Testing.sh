#!/bin/bash

# Remove old executable
rm -f Testing

# Compile the C++ files with pthread support
g++ ExtendedTesting.cpp -o Testing

# Check if compilation was successful
if [ $? -eq 0 ]; then
    echo "Compilation successful. Running the program..."
    ./Testing
else
    echo "Compilation failed."
fi
