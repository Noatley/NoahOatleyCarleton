#ifndef INET_HELPERS_HPP
#define INET_HELPERS_HPP

#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include "Datagram.hpp"
#include "Globals.hpp"

bool isPortAvailable(int port);
void sendToSubsystem(int port, std::vector<uint8_t> &data); //send data to port
std::vector<uint8_t> receiveFromSubsystem(DatagramSocket &receiveSocket); //return data from port

#endif