#include "DisplayUI.hpp"
#include "Globals.hpp"
#include "pthread.h"


void changeElevatorStatus(sharedData* shared, int elevatorID, const char* status, int floor) {
    ElevatorStatus elevatorStatus;
    elevatorStatus.elevatorID = elevatorID;
    strcpy(elevatorStatus.currentStatus, status); //status needs to be like UP, DOWN, Stationary, Open, Critical Error - Floor #
    elevatorStatus.currentFloor = floor;

    pthread_mutex_lock(&shared->mutex);
    shared->elevatorStatuses[elevatorID - 1] = elevatorStatus;
    pthread_mutex_unlock(&shared->mutex);
}


void updateElevator1(sharedData* shared) { //timings are correct
    changeElevatorStatus(shared, 1, "UP - Floor 2", 1);
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime)); //1314
    changeElevatorStatus(shared, 1, "Stationary", 2);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //4922
    changeElevatorStatus(shared, 1, "Open", 2);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //9736
    changeElevatorStatus(shared, 1, "Stationary", 2);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //13344

    changeElevatorStatus(shared, 1, "UP - Floor 16", 1);
    for (int i = 1; i <= 14; ++i) {
        changeElevatorStatus(shared, 1, "UP - Floor 16", i);
        std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime)); //31740
    }
    changeElevatorStatus(shared, 1, "Stationary", 16);    
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //35348
    changeElevatorStatus(shared, 1, "Open", 16);    
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //40162
    changeElevatorStatus(shared, 1, "Stationary", 16);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //43770

    std::this_thread::sleep_for(std::chrono::milliseconds(43230)); //waiting for next request, 87000

    for (int i = 16; i >= 11; --i) {
        changeElevatorStatus(shared, 1, "DOWN - Floor 11", i);
        std::this_thread::sleep_for(std::chrono::milliseconds(int(elevatorTravelTime * 0.648))); //92256
    }
    changeElevatorStatus(shared, 1, "Stationary", 11);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //95864
    changeElevatorStatus(shared, 1, "Open", 11);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime));  //100178
    changeElevatorStatus(shared, 1, "Stationary", 11);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //103786

    for (int i = 11; i <= 16; ++i) {
        changeElevatorStatus(shared, 1, "UP - Floor 16", i);
        std::this_thread::sleep_for(std::chrono::milliseconds(int(elevatorTravelTime * 0.648))); //111670
    }
    changeElevatorStatus(shared, 1, "Stationary", 16);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //112650
    changeElevatorStatus(shared, 1, "Open", 16);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime));  // 117464
    changeElevatorStatus(shared, 1, "Stationary", 16);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //121072
}

void updateElevator2(sharedData* shared) {
    std::this_thread::sleep_for(std::chrono::milliseconds(14000)); 

    for (int i = 1; i <= 18; ++i) {
        changeElevatorStatus(shared, 2, "UP - Floor 19", i);
        std::this_thread::sleep_for(std::chrono::milliseconds(int(elevatorTravelTime))); //37652
    }
    changeElevatorStatus(shared, 2, "Stationary", 19);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //41260
    changeElevatorStatus(shared, 2, "Open", 19);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //46074
    changeElevatorStatus(shared, 2, "Stationary", 19);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //49682

    std::this_thread::sleep_for(std::chrono::milliseconds(54318)); //waiting for next request, 104000

    for (int i = 19; i >= 14; --i) {
        changeElevatorStatus(shared, 2, "DOWN - Floor 1", i);
        std::this_thread::sleep_for(std::chrono::milliseconds(int(elevatorTravelTime * 0.644))); //109256
    }
    changeElevatorStatus(shared, 2, "Stationary", 14);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //115264
    changeElevatorStatus(shared, 2, "Open", 14);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); // 120078
    changeElevatorStatus(shared, 2, "Stationary", 14);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //123686

    for (int i = 14; i >= 9; --i) {
        changeElevatorStatus(shared, 2, "DOWN - Floor 9", i);
        std::this_thread::sleep_for(std::chrono::milliseconds(int(elevatorTravelTime * 0.653))); //128942
    }
    changeElevatorStatus(shared, 2, "Stationary", 9);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //132550
    changeElevatorStatus(shared, 2, "Open", 9);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //137364
    changeElevatorStatus(shared, 2, "Stationary", 9);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //140972

    for (int i = 9; i >= 1; --i) {
        changeElevatorStatus(shared, 2, "DOWN - Floor 1", i);
        std::this_thread::sleep_for(std::chrono::milliseconds(int(elevatorTravelTime * 0.78))); //145228
    }
    changeElevatorStatus(shared, 2, "Stationary", 1);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //153778
    changeElevatorStatus(shared, 2, "Open", 1);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //158592
    changeElevatorStatus(shared, 2, "Stationary", 1);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //162200

    for (int i = 1; i <= 22; ++i) {
        changeElevatorStatus(shared, 2, "UP - Floor 22", i);
        std::this_thread::sleep_for(std::chrono::milliseconds(int(elevatorTravelTime * 0.90))); //188480
    }
    changeElevatorStatus(shared, 2, "Stationary", 22);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //191088
    changeElevatorStatus(shared, 2, "Open", 22);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); // 195902
    changeElevatorStatus(shared, 2, "Stationary", 22);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //199510
}

void updateElevator3(sharedData* shared) {
    std::this_thread::sleep_for(std::chrono::milliseconds(49000)); 

    for (int i = 1; i <= 17; ++i) {
        changeElevatorStatus(shared, 3, "UP - Floor 17", i);
        std::this_thread::sleep_for(std::chrono::milliseconds(int(elevatorTravelTime * 0.944))); //70024
    }
    changeElevatorStatus(shared, 3, "Stationary", 17);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //73632
    changeElevatorStatus(shared, 3, "Open", 17);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //78446
    changeElevatorStatus(shared, 3, "Stationary", 17);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //82054
    
    for (int i = 17; i >= 2; --i) {
        changeElevatorStatus(shared, 3, "DOWN - Floor 2", i);
        std::this_thread::sleep_for(std::chrono::milliseconds(int(elevatorTravelTime * 0.885))); //100450
    }
    changeElevatorStatus(shared, 3, "Stationary", 2);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //104058
    changeElevatorStatus(shared, 3, "DOWN - Floor 1", 2);
    std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime)); //105372
    changeElevatorStatus(shared, 3, "Stationary", 1);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //108980
    changeElevatorStatus(shared, 3, "Open", 1);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //113794
    changeElevatorStatus(shared, 3, "Stationary", 1);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //117402

}

void updateElevator4(sharedData* shared) {
    std::this_thread::sleep_for(std::chrono::milliseconds(82000)); 
    for (int i = 1; i <= 17; ++i) {
        changeElevatorStatus(shared, 4, "UP - Floor 17", i);
        std::this_thread::sleep_for(std::chrono::milliseconds(int(elevatorTravelTime * 0.93))); //103024
    }
    changeElevatorStatus(shared, 4, "Stationary", 17);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //106632
    changeElevatorStatus(shared, 4, "Open", 17);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //111446
    changeElevatorStatus(shared, 4, "Stationary", 17);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //115054

    for (int i = 17; i >= 14; --i) {
        changeElevatorStatus(shared, 4, "DOWN - Floor 3", i);
        std::this_thread::sleep_for(std::chrono::milliseconds(int(elevatorTravelTime * 0.63))); //119862
    }
    changeElevatorStatus(shared, 4, "Stationary", 14);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //123470
    changeElevatorStatus(shared, 4, "Open", 14);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //128284
    changeElevatorStatus(shared, 4, "Critical Error", 14);
}


int main() {
    initialize_ncurses();
    SharedMemoryManager shm;
    sharedData* shared = shm.get();

    std::thread elevator1Update(updateElevator1, shared);
    std::thread elevator2Update(updateElevator2, shared);
    std::thread elevator3Update(updateElevator3, shared);
    std::thread elevator4Update(updateElevator4, shared);

    
    while (true) {
        clear();
        
        // Lock mutex before reading shared data
        
        display_subsystem_status(shared);


        
        display_elevator_movement(shared);
        
        // Unlock mutex after reading
        
        refresh(); 
        std::this_thread::sleep_for(std::chrono::milliseconds(200)); // Refresh rate
    }

    elevator1Update.join();
    elevator2Update.join();
    elevator3Update.join();
    elevator4Update.join();
    
    endwin();
    return 0;
}