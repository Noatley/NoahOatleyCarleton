#include "FloorSubsystem.hpp"

FloorSubsystem::FloorSubsystem(std::string fileName) : receiveSocket(FLOORPORT), openSocket(OPENPORT), floorStatus("Operational") { //constructor needs to grab input file data and store it to create inputs
    floors.resize(numFloors); //resize the floors vector to the max number of floors
    std::ifstream inputFile(fileName); //initialize ifstream for input file
    assert(inputFile.is_open()); //make sure file exists
    parseFile(inputFile); //run the parse method to interpret file contents
    inputFile.close(); //close file
    if(Testing == 0){
        floorThread = std::thread(&FloorSubsystem::monitorOpen, this);
    }

    initialTime = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()
    );
    endFloor = 0;

    SharedMemoryManager shm;
    sharedData* shared = shm.get();
}

void FloorSubsystem::monitorOpen() {
    while (true) {
        std::vector<uint8_t> data = receiveFromSubsystem(openSocket);

        assert (data[0] == 0); //check if the data is meant to be for the floor

        if (data[2] == 2){ //Packet type = 2, scheduler tells floor to open door
            openDoor(data[1]);
        }
    }
    
}

//FLOOR->SCHEDULER
bool FloorSubsystem::sendToScheduler() { //send floorrequests to scheduler
    if (!inputs.empty()) { //wait until theres requests in the internal input queue, or timeout after 500ms
        std::this_thread::sleep_for(std::chrono::milliseconds(abs(initialTime - inputs.top().time)));
        initialTime = inputs.top().time;
        std::vector<uint8_t> requestData = parseRequest(inputs.top());
        sendToSubsystem(SCHEDULERFLOORPORT, requestData); //send the request to the scheduler
        inputs.pop(); 
        return true;
    } else {
        return false;
    }
}

//SCHEDULER->FLOOR
void FloorSubsystem::receiveFromScheduler() { 
    std::vector<uint8_t> data = receiveFromSubsystem(receiveSocket); //receive data from scheduler

    assert (data[0] == 0); //check if the data is meant to be for the floor

    if (data[2] == 1){ //Packet type = 1, scheduler notifies floor that elevator has arrived at that floor.
        std::cout << "[FLOOR]: Elevator detected on floor: " << static_cast<int>(data[3]) << std::endl;
    }
}

void FloorSubsystem::openDoor(int floor) {
    std::cout << "[FLOOR]: Opening door on floor " << floor <<"." << std::endl;
    floorUpdate(floor, true);
    std::this_thread::sleep_for(std::chrono::seconds(doorOpeningTime + doorOpenTime)); //Simulate door opening
    std::cout << "[FLOOR]: Closing door on floor " << floor << "." << std::endl;
    floorUpdate(floor, false);
    std::this_thread::sleep_for(std::chrono::seconds(doorOpeningTime)); //Simulate door closing
    if (floor == endFloor) {
        auto currentTime = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()
        );
        
        auto elapsedTime = currentTime - initialTime;
        std::cout << "Total time: " << elapsedTime.count() << " ms" << std::endl;
    }
}

//main thread function to run the floor
void FloorSubsystem::runFloor() {
    while (true) {
        if (sendToScheduler()) {   //send floor requests to Scheduler
            receiveFromScheduler(); //receive completed floors
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(100)); 
    }
}


//update shared memory data
void FloorSubsystem::updateFloorStatus(sharedData* shared, const FloorStatus& new_status) {
    pthread_mutex_lock(&shared->mutex);
    
    // Copy the entire structure atomically
    strncpy(shared->floorStatus.currentStatus, new_status.currentStatus, 
           sizeof(shared->floorStatus.currentStatus));
    
    shared->floorStatus.count = new_status.count;
    for (int i = 0; i < 32; ++i) {
        strncpy(shared->floorStatus.floor[i], new_status.floor[i],
               sizeof(shared->floorStatus.floor[i]));
    }
    
    shared->ready.store(true, std::memory_order_release);
    pthread_mutex_unlock(&shared->mutex);
}

void FloorSubsystem::floorUpdate(int floor, bool open) {
    char statusStr[32];
    snprintf(statusStr, sizeof(statusStr), "%d Open", floor);
    
    // Create local copy while locked
    FloorStatus localStatus;
    pthread_mutex_lock(&shared->mutex);
    localStatus = shared->floorStatus;
    pthread_mutex_unlock(&shared->mutex);
    
    if (open) {
        // Add to first empty slot
        if (localStatus.count < 32) {
            for (int i = 0; i < 32; ++i) {
                if (localStatus.floor[i][0] == '\0') {
                    strncpy(localStatus.floor[i], statusStr, sizeof(localStatus.floor[i]));
                    localStatus.count++;
                    break;
                }
            }
        }
    } else {
        // Find and remove the status
        for (int i = 0; i < 32; ++i) {
            if (strcmp(localStatus.floor[i], statusStr) == 0) {
                // Compact the array first
                for (int j = i; j < 31; j++) {
                    strncpy(localStatus.floor[j], localStatus.floor[j+1], 
                           sizeof(localStatus.floor[j]));
                }
                localStatus.floor[31][0] = '\0'; // Clear last element
                localStatus.count--;
                break;
            }
        }
    }
    
    updateFloorStatus(shared, localStatus);
}



//getters
std::priority_queue<RequestStructure, std::vector<RequestStructure>, RequestComparator> FloorSubsystem::getInputs() {
    return inputs;
}

//setters
void FloorSubsystem::setInputs(std::priority_queue<RequestStructure, std::vector<RequestStructure>, RequestComparator> in) {
    inputs = in;
}

void FloorSubsystem::parseFile(std::ifstream& inputFileStream) {
    std::string line;

    while (std::getline(inputFileStream, line)) {
        std::stringstream ss(line);
        std::string timeStr, dirStr;
        std::chrono::milliseconds time;
        int curr, dest;
        int err = 0, errFloor = 0; // Default values for optional fields
        bool dir;

        ss >> timeStr >> curr >> dirStr >> dest;

        // Check if there are more fields for error and errorFloor
        if (ss >> err >> errFloor) {
            // Successfully read err and errFloor
        } else {
            // Reset the stream state and clear the error flags
            ss.clear();
        }

        if (dest < 1 || dest > numFloors || curr < 1 || curr > numFloors) {
            invalidInput = true;
        } else {
            time = chronoConversion(timeStr);

            if (dirStr == "Up" || dirStr == "up") {
                dir = true;
            } else if (dirStr == "Down" || dirStr == "down") {
                dir = false;
            } else {
                throw std::invalid_argument("Wrong direction");
            }

            RequestStructure input(time, curr, dest, dir, err, errFloor);
            inputs.push(input);

            std::cout << "[FLOOR]: Parsed request: Current Floor: " << input.originFloor << ", Direction: " << input.direction << ", Destination Floor: " << input.destination << std::endl;
        }
    }
    if(invalidInput == false){
        initialTime = inputs.top().time;
    }
}

std::vector<uint8_t> FloorSubsystem::parseRequest(RequestStructure request) { //function to parse request structure into a vector of bytes
    std::vector<uint8_t> data; //initialize vector of bytes
    data.clear();
    data.push_back(0); //add floor identifier to data as 0
    data.push_back(request.originFloor); //add origin floor to data
    data.push_back(0); //add packet type identifier to data as 0
    data.push_back(request.destination); //add destination to data
    data.push_back(request.error);
    data.push_back(request.errorFloor);
    return data; //return data
}

std::chrono::milliseconds FloorSubsystem::chronoConversion(std::string time) { //function to take entire time string and convert to ms
    int hours, minutes, seconds, milliseconds;
    char colon, period;

    std::istringstream timeStream(time); //create stringstream from time
    timeStream >> hours >> colon >> minutes >> colon >> seconds >> period >> milliseconds; //if formatted correctly, should fit into all variables

    return std::chrono::hours(hours) + std::chrono::minutes(minutes) + std::chrono::seconds(seconds) + std::chrono::milliseconds(milliseconds); //add up converted times and return
}

bool FloorSubsystem::getInvalidInput() {
    return invalidInput;
}







//testing code

