#include "FloorSubsystem.hpp"

int main (){
    std::cout << "[FLOOR]: Parsed request: Current Floor: 2, Direction: 1, Destination Floor: 16" << std::endl; //at 0
    std::cout << "[FLOOR]: Parsed request: Current Floor: 1, Direction: 1, Destination Floor: 19" << std::endl; //at 14s
    std::cout << "[FLOOR]: Parsed request: Current Floor: 17, Direction: 0, Destination Floor: 2" << std::endl; //at 49s
    std::cout << "[FLOOR]: Parsed request: Current Floor: 17, Direction: 0, Destination Floor: 3" << std::endl; //at 1m22s
    std::cout << "[FLOOR]: Parsed request: Current Floor: 11, Direction: 1, Destination Floor: 16" << std::endl; //at 1m27
    std::cout << "[FLOOR]: Parsed request: Current Floor: 1, Direction: 1, Destination Floor: 17" << std::endl; //at 1m44s
    std::cout << "[FLOOR]: Parsed request: Current Floor: 14, Direction: 0, Destination Floor: 9" << std::endl; //at 1m49s

    std::this_thread::sleep_for(std::chrono::milliseconds(4922)); //4922
    std::cout << "[FLOOR]: Opening door on floor 2." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //9736
    std::cout << "[FLOOR]: Closing door on floor 2." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime)); //13344

    std::this_thread::sleep_for(std::chrono::milliseconds(22004)); //35348
    std::cout << "[FLOOR]: Opening door on floor 16." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //40162
    std::cout << "[FLOOR]: Closing door on floor 16." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(1098)); //41260
    std::cout << "[FLOOR]: Opening door on floor 19." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //46074
    std::cout << "[FLOOR]: Closing door on floor 19." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(27558)); //73632
    std::cout << "[FLOOR]: Opening door on floor 17." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //78446
    std::cout << "[FLOOR]: Closing door on floor 17." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(17358)); //95864
    std::cout << "[FLOOR]: Opening door on floor 11." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //100178
    std::cout << "[FLOOR]: Closing door on floor 11." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(3380)); //104058
    std::cout << "[FLOOR]: Unable to open door on floor 2." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(2574)); //106632
    std::cout << "[FLOOR]: Opening door on floor 17." << std::endl;
    
    std::this_thread::sleep_for(std::chrono::milliseconds(2348)); //108980
    std::cout << "[FLOOR]: Opening door on floor 1." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(2466)); //111446
    std::cout << "[FLOOR]: Closing door on floor 17." << std::endl;
    
    std::this_thread::sleep_for(std::chrono::milliseconds(1204)); //112650
    std::cout << "[FLOOR]: Opening door on floor 16." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(1144)); //113794
    std::cout << "[FLOOR]: Closing door on floor 1." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(1470)); //115264
    std::cout << "[FLOOR]: Opening door on floor 14." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(2200)); //117464
    std::cout << "[FLOOR]: Closing door on floor 16." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(2614)); //120078
    std::cout << "[FLOOR]: Closing door on floor 14." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(3392)); //123470
    std::cout << "[FLOOR]: Opening door on floor 14." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(7580)); //132550
    std::cout << "[FLOOR]: Opening door on floor 9." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //137364
    std::cout << "[FLOOR]: Closing door on floor 9." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(15728)); //153778
    std::cout << "[FLOOR]: Opening door on floor 1." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //158592
    std::cout << "[FLOOR]: Closing door on floor 1." << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(33104)); //191088
    std::cout << "[FLOOR]: Opening door on floor 22." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpenTime)); //195902
    std::cout << "[FLOOR]: Closing door on floor 22." << std::endl;

    std::cout << "Total time: 195902 ms" << std::endl;

}

