#include "ElevatorSubsystem.hpp"
#include "ElevatorStatemachine.hpp"


float duration = 0;
int movement = 0;

ElevatorSubsystem::ElevatorSubsystem(int port) : currentFloor(1), direction(true), elevatorSocket(port), internal_port(port), elevatorID(port - OFFSET), pingResponse(false), openResponse(true), capacity(0), completedFloors(), error(false), errorFloor(0), operational(true), elevatorStatus(elevatorID, "Stationary", 1) {
    SharedMemoryManager shm;
    shared = shm.get();
}

//ELEVATOR->SCHEDULER
void ElevatorSubsystem::sendToScheduler() {
    while (true) {
        if (!operational) {
            return;
        }
        if (!completedFloors.empty()) {
            while (!completedFloors.empty()) {
                int value = *completedFloors.begin();
                pickups.insert(value);
                completedFloors.erase(value);
                std::vector<uint8_t> responseData;
                responseData.push_back(1); //Identifier, 1 indicates it is from ElevatorSubsystem
                responseData.push_back(static_cast<uint8_t>(elevatorID)); //Elevator ID, indicates which elevator car
                responseData.push_back(1); //Packet Type, 1 indicates that elevator arrived at floor
                responseData.push_back(static_cast<uint8_t>(currentFloor)); //Notification, scheduler does not care
                sendToSubsystem(SCHEDULERPORT, responseData); //send the request to the scheduler
            }
        } 
        else if (pingResponse) {
            pingResponse = false;
            std::vector<uint8_t> responseData;
            responseData.push_back(1);
            responseData.push_back(elevatorID);
            responseData.push_back(4);
            responseData.push_back(direction == true ? 1 : 0);
            responseData.push_back(currentFloor);
            responseData.push_back(capacity);

            sendToSubsystem(SCHEDULEROFFSET + elevatorID, responseData);
        }
        else if (error) {
            std::vector<uint8_t> errorData;
            if (recoverable) { // Error happened is fixable, will skip that floor and continue
                error = false;
                errorData.push_back(1);
                errorData.push_back(elevatorID);
                errorData.push_back(5); // Error packet identifier
                errorData.push_back(1); // Recoverable identifier
                errorData.push_back(currentFloor);
            }
            else { // Error is not recoverable, send current floor, up queue, down queue
                errorData.push_back(1);
                errorData.push_back(elevatorID);
                errorData.push_back(5);
                errorData.push_back(0);
                errorData.push_back(currentFloor);
                errorData.push_back(0);
                for(auto iterate : upQueue) { // Send its whole up and down queue to be rescheduled
                    errorData.push_back(iterate);
                }
                errorData.push_back(0);
                for(auto iterate : downQueue) {
                    errorData.push_back(iterate);
                }
                errorData.push_back(0);

                operational = false;
            }

            sendToSubsystem(SCHEDULEROFFSET + elevatorID, errorData);
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}


void ElevatorSubsystem::createThreads() {
        sendThread = std::thread(&ElevatorSubsystem::sendToScheduler, this);
        listenerThread = std::thread(&ElevatorSubsystem::receiveFromScheduler, this);
}

//SCHEDULER->ELEVATOR
void ElevatorSubsystem::receiveFromScheduler() {
    while(true) { // Loop to receive data
        if (!operational) {
            return;
        }
        std::vector<uint8_t> receivedData = receiveFromSubsystem(elevatorSocket);
        assert(elevatorID == receivedData[1]);  // Ensure correct elevator ID

        std::cout << "received from scheduler" << std::endl;

        if (receivedData[2] == 2) {
            // If the packet type is 2, it indicates that the elevator has arrived at the floor and is ready to open doors
            openDoors();
        } 
        else if (receivedData[2] == 0) {  // Packet type 0 indicates a new floor request
            int originFloor = receivedData[3];
            int destinationFloor = receivedData[4];
            errorSeverity = receivedData[5];
            errorFloor = receivedData[6];

            if (originFloor < destinationFloor) { //if the origin floor is below the destination floor (origin up to destination)
                if (currentFloor < originFloor) { //current floor < origin floor < destination floor; elevator >>
                    upQueue.insert(originFloor);
                    upQueue.insert(destinationFloor);
                }
                else if (currentFloor > originFloor && currentFloor < destinationFloor) {
                    //needs some logic with the requirements 2d array [[O, D], [O, D]...]
                    addRequirements(originFloor, destinationFloor);
                    downQueue.insert(originFloor);
                    upQueue.insert(destinationFloor);
                }
                else { //origin floor < destination floor < current floor; elevator << and then >>
                    downQueue.insert(originFloor);
                    upQueue.insert(destinationFloor);
                }
            }
            else { //origin floor is above the destination floor (origin down to destination)
                if (currentFloor > originFloor) { //destination floor < origin floor < current floor; elevator <<
                    downQueue.insert(originFloor);
                    downQueue.insert(destinationFloor);
                }
                else if (currentFloor < originFloor && currentFloor > destinationFloor) {
                    //needs some logic with the requirements 2d array [[O, D], [O, D]...]
                    addRequirements(originFloor, destinationFloor);
                    upQueue.insert(originFloor);
                    downQueue.insert(destinationFloor);
                }
                else { //current floor < destination floor < origin floor; elevator >> and then <<
                    upQueue.insert(originFloor);
                    downQueue.insert(destinationFloor);
                }
            }

            // Determine whether the origin floor is above or below the current floor
            if (originFloor < currentFloor) {
                downQueue.insert(originFloor);  // Add to down queue if below the current floor
            } else {
                upQueue.insert(originFloor);    // Add to up queue if above the current floor
            }
        } 
        else if (receivedData[2] == 3) {
            // If packet type is 3, it's a ping response
            pingResponse = true;
        }
    }
}


//Main thread function to run the elevator
void ElevatorSubsystem::runElevator() {
    createThreads();
    while (true) {
        elevatorContext.performAction(); 

        //receiveFromScheduler(); // Ensure this is called to receive requests

        while (upQueue.empty() && downQueue.empty()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        while (elevatorContext.getCurrentElevatorState() == ElevatorStates::ARRIVED) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(elevatorStartTime));

        if (direction) {
            moveUp();
        } else {
            moveDown();
        }

        if ((upQueue.empty() && !downQueue.empty()) || (direction && std::all_of(upQueue.begin(), upQueue.end(), [this](int floor) {return floor < currentFloor;}))) {
            direction = false;  // Switch direction if no more requests in the upQueue
            elevatorContext.setDirection(0);  // Update direction in state machine
        }

        if ((downQueue.empty() && !upQueue.empty()) || (!direction && std::all_of(downQueue.begin(), downQueue.end(), [this](int floor) {return floor > currentFloor;}))) {
            direction = true;  // Switch direction if no more requests in the downQueue
            elevatorContext.setDirection(1);  // Update direction in state machine
        }
    }
}

void ElevatorSubsystem::moveToFloor(int newFloor) {
    if (direction == true && newFloor < currentFloor) {
        direction = false;
        elevatorContext.setDirection(0);
    }
    else if (direction == false && newFloor > currentFloor) {
        direction = true;
        elevatorContext.setDirection(1);
    }
    elevatorContext.setPrevElevatorState(elevatorContext.getCurrentElevatorState());
    elevatorContext.setElevatorState(ElevatorStates::MOVING);
    movement++;
    std::cout << "[ELEVATOR " << elevatorID << "]: Movement count: " << movement << std::endl;

    if (currentFloor != newFloor) {
        if (operational && currentFloor != newFloor) {
            std::cout << "[ELEVATOR " << elevatorID << "]: Moving from " << currentFloor << " to " << newFloor << std::endl;
        }
        else if (!operational) {
            return;
        }
        while (currentFloor != newFloor) {
            std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime));
            duration += elevatorTravelTime;
            std::cout << "[ELEVATOR " << elevatorID << "]: Recorded time (ms): " << duration << std::endl;
            currentFloor += direction == 1 ? 1 : -1;
            elevatorUpdate(false);
            if(currentFloor == errorFloor && errorSeverity == 2 && operational != false) { // Non recoverable error, must fail
                capacity = 0; // Empty the elevator for everyone to get off
                error = true;
                recoverable = false;
                std::cout << "[ELEVATOR " << elevatorID << "]: Encountered an non recoverable error at floor " << currentFloor << std::endl;
                elevatorContext.setElevatorState(ElevatorStates::STATIONARY);
                operational = false;
                return;
            }
        }
        elevatorContext.setCurrentFloor(newFloor); // Update state machine
        elevatorContext.setElevatorState(ElevatorStates::ARRIVED);
        if (operational) {
            std::cout << "[ELEVATOR " << elevatorID << "]: Elevator arrived at floor " << currentFloor << std::endl;

        }
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime));

    elevatorContext.setPrevElevatorState(elevatorContext.getCurrentElevatorState());
    elevatorContext.setElevatorState(ElevatorStates::ARRIVED);

    // Mark doors as not open yet
    openResponse = false;

    std::vector<uint8_t> arrivalMsg;
    arrivalMsg.push_back(1);
    arrivalMsg.push_back(elevatorID);
    arrivalMsg.push_back(1);
    arrivalMsg.push_back((currentFloor == errorFloor && errorSeverity == 1) ? currentFloor + (direction ? 1 : -1) : currentFloor);
    sendToSubsystem(SCHEDULEROFFSET + elevatorID, arrivalMsg);

    std::this_thread::sleep_for(std::chrono::seconds(10));

    openResponse = true;
}

void ElevatorSubsystem::moveOne() {
    moveToFloor(currentFloor + (direction ? 1 : -1));
    if (isOrigin(currentFloor)) {
        capacity++;
    } else {
        capacity--;
    }
}

void ElevatorSubsystem::moveUp() {
    // First handle pickups in the correct order
    while (!upQueue.empty() && direction == true) {
        for (auto it = upQueue.begin(); it != upQueue.end(); ) {
            int floor = *it;
            if (floor > currentFloor) {  // Only move to higher floors
                moveToFloor(floor);
                if (isOrigin(floor)) {
                    capacity++;
                } else {
                    capacity--;
                }
                it = upQueue.erase(it);  // Use the iterator returned by erase
            } else {
                ++it;
            }
        }

        if ((upQueue.empty() && !downQueue.empty()) || (direction && std::all_of(upQueue.begin(), upQueue.end(), [this](int floor) {return floor < currentFloor;}))) {
            direction = false;  // Switch direction if no more requests in the upQueue
            elevatorContext.setDirection(0);  // Update direction in state machine
            break;
        }
    }

    // Now check the direction and move completed floors to the correct queue
    // Check if the elevator is already at its destination floor, then adjust the queue and direction
    completedFloors.insert(currentFloor);

    if ((upQueue.empty() && !downQueue.empty()) || (direction && std::all_of(upQueue.begin(), upQueue.end(), [this](int floor) {return floor < currentFloor;}))) {
        direction = false;  // Switch direction if no more requests in the upQueue
        elevatorContext.setDirection(0);  // Update direction in state machine
    }
}


void ElevatorSubsystem::moveDown() {
    // First handle pickups in the correct order
    while (!downQueue.empty() && !direction) {
        for (auto it = downQueue.begin(); it != downQueue.end(); ) {
            int floor = *it;
            if (floor < currentFloor) {  // Only move to lower floors
                moveToFloor(floor);
                if (isOrigin(floor)) {
                    capacity++;
                } else {
                    capacity--;
                }
                it = downQueue.erase(it);  // Use the iterator returned by erase
            } else {
                ++it;
            }
        }

        if ((downQueue.empty() && !upQueue.empty()) || (!direction && std::all_of(downQueue.begin(), downQueue.end(), [this](int floor) {return floor > currentFloor;}))) {
            direction = true;  // Switch direction if no more requests in the downQueue
            elevatorContext.setDirection(1);  // Update direction in state machine
            break;
        }
    }

    // Now check the direction and move completed floors to the correct queue
    // Check if the elevator is already at its destination floor, then adjust the queue and direction
    completedFloors.insert(currentFloor);

    if ((downQueue.empty() && !upQueue.empty()) || (!direction && std::all_of(downQueue.begin(), downQueue.end(), [this](int floor) {return floor > currentFloor;}))) {
        direction = true;  // Switch direction if no more requests in the downQueue
        elevatorContext.setDirection(1);  // Update direction in state machine
    }
}



void ElevatorSubsystem::openDoors() {
    if(errorSeverity == 1 && errorFloor == currentFloor) { // Error occurs, send message
        std::cout << "[ELEVATOR " << elevatorID << "]: Encountered an error opening doors on floor " << currentFloor << ". Moving to the next floor." << std::endl;
        error = true;
        recoverable = true;
        capacity = 0;
        moveOne();
    }
    std::cout << "[ELEVATOR " << elevatorID << "]: Opening doors on floor " << currentFloor << std::endl;
    elevatorUpdate(true);
    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime + doorOpenTime)); //Simulate door opening
    duration += doorOpeningTime + doorOpenTime;
    std::cout << "[ELEVATOR " << elevatorID << "]: Closing doors on floor " << currentFloor << std::endl;
    elevatorUpdate(false);
    std::this_thread::sleep_for(std::chrono::seconds(doorOpeningTime)); //Simulate door closing, assuming opening time is the same as closing time
    duration += doorOpeningTime;
    std::cout << "[ELEVATOR " << elevatorID << "]: Recorded time (ms): " << duration << std::endl;
}



void ElevatorSubsystem::addRequirements(int originFloor, int destinationFloor) {
    std::vector<int> requirement(2);
    requirement.clear();
    requirement.push_back(originFloor);
    requirement.push_back(destinationFloor);
    requirements.push_back(requirement);
}

bool ElevatorSubsystem::isOrigin(int floor) {
    for (auto it = requirements.begin(); it != requirements.end(); ++it) {
        if ((*it)[0] == floor) {
            requirements.erase(it);
            return true;
        }
        if ((*it)[1] == floor) {
            return false;
        }
    }
    return false;
}

//shared memory update
void ElevatorSubsystem::updateElevatorStatus(sharedData* shared, const ElevatorStatus& new_status) {
    // Validate elevator ID first
    if (elevatorID < 0 || elevatorID >= 4) {
        std::cerr << "Invalid elevator ID: " << elevatorID << std::endl;
        return;
    }

    pthread_mutex_lock(&shared->mutex);
    // Update only the specific elevator's status
    shared->elevatorStatuses[elevatorID].currentFloor = new_status.currentFloor;
    strncpy(shared->elevatorStatuses[elevatorID].currentStatus, 
           new_status.currentStatus,
           sizeof(shared->elevatorStatuses[elevatorID].currentStatus));
    
    shared->ready.store(true, std::memory_order_release);
    pthread_mutex_unlock(&shared->mutex);
}

void ElevatorSubsystem::elevatorUpdate(bool open) {
    // Create local status update
    ElevatorStatus localStatus = elevatorStatus;
    localStatus.currentFloor = currentFloor;
    
    // Determine status string based on state
    const char* statusStr;
    if (elevatorContext.getState() == ElevatorStates::STATIONARY || 
        elevatorContext.getState() == ElevatorStates::ARRIVED) {
        statusStr = open ? "Open" : "Stationary";
    }
    else if (elevatorContext.getState() == ElevatorStates::MOVING) {
        statusStr = direction ? "UP" : "DOWN";
    }
    else {
        statusStr = "Unknown";
    }
    
    // Update the status
    strncpy(localStatus.currentStatus, statusStr, sizeof(localStatus.currentStatus));
    
    // Push update to shared memory
    updateElevatorStatus(shared, localStatus);
}



//getters for the test files
std::set<int> ElevatorSubsystem::getUpQueue() {
    return upQueue;
}

std::set<int> ElevatorSubsystem::getDownQueue() {
    return downQueue;
}

int ElevatorSubsystem::getCurrentFloor() const {
    return currentFloor;
}

int ElevatorSubsystem::getElevatorID() const {
    return elevatorID;
}

std::set<int> ElevatorSubsystem::getCompletedFloors() {
    return completedFloors;
}

bool ElevatorSubsystem::getDirection() {
    return direction;
}

ElevatorStates ElevatorContext::getCurrentState() {
    return currentElevatorState;
}

//setters for test files
void ElevatorSubsystem::setCompletedFloors(std::set<int> completed) {
    completedFloors = completed;
}

// Extra Functions for Testing

//ELEVATOR->SCHEDULER
void ElevatorSubsystem::sendToScheduler_Testing() {
    if (!operational) {
        return;
    }
    if (!completedFloors.empty()) {
        while (!completedFloors.empty()) {
            int value = *completedFloors.begin();
            pickups.insert(value);
            completedFloors.erase(value);
            std::vector<uint8_t> responseData;
            responseData.push_back(1); //Identifier, 1 indicates it is from ElevatorSubsystem
            responseData.push_back(static_cast<uint8_t>(elevatorID)); //Elevator ID, indicates which elevator car
            responseData.push_back(1); //Packet Type, 1 indicates that elevator arrived at floor
            responseData.push_back(static_cast<uint8_t>(currentFloor)); //Notification, scheduler does not care
            sendToSubsystem(SCHEDULERPORT, responseData); //send the request to the scheduler
        }
    } 
    else if (pingResponse) {
        pingResponse = false;
        std::vector<uint8_t> responseData;
        responseData.push_back(1);
        responseData.push_back(elevatorID);
        responseData.push_back(4);
        responseData.push_back(direction == true ? 1 : 0);
        responseData.push_back(currentFloor);
        responseData.push_back(capacity);

        sendToSubsystem(SCHEDULEROFFSET + elevatorID, responseData);
    }
    else if (error) {
        std::vector<uint8_t> errorData;
        if (recoverable) { // Error happened is fixable, will skip that floor and continue
            error = false;
            errorData.push_back(1);
            errorData.push_back(elevatorID);
            errorData.push_back(5); // Error packet identifier
            errorData.push_back(1); // Recoverable identifier
            errorData.push_back(currentFloor);
        }
        else { // Error is not recoverable, send current floor, up queue, down queue
            errorData.push_back(1);
            errorData.push_back(elevatorID);
            errorData.push_back(5);
            errorData.push_back(0);
            errorData.push_back(currentFloor);
            errorData.push_back(0);
            for(auto iterate : upQueue) { // Send its whole up and down queue to be rescheduled
                errorData.push_back(iterate);
            }
            errorData.push_back(0);
            for(auto iterate : downQueue) {
                errorData.push_back(iterate);
            }
            errorData.push_back(0);

            operational = false;
        }

        sendToSubsystem(SCHEDULEROFFSET + elevatorID, errorData);
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
}


//SCHEDULER->ELEVATOR
void ElevatorSubsystem::receiveFromScheduler_Testing() {
    std::cout << "ElevatorSubsystem " << elevatorID << " is receiving from the scheduler" << std::endl;
    if (!operational) {
        return;
    }
    std::vector<uint8_t> receivedData = receiveFromSubsystem(elevatorSocket);
    assert(elevatorID == receivedData[1]);  // Ensure correct elevator ID
    printf("%d\n", receivedData[2]);
    if (receivedData[2] == 2) {
        // If the packet type is 2, it indicates that the elevator has arrived at the floor and is ready to open doors
        openDoors();
    } 
    else if (receivedData[2] == 0) {  // Packet type 0 indicates a new floor request
        int originFloor = receivedData[3];
        int destinationFloor = receivedData[4];
        errorSeverity = receivedData[5];
        errorFloor = receivedData[6];

        if (originFloor < destinationFloor) { //if the origin floor is below the destination floor (origin up to destination)
            if (currentFloor < originFloor) { //current floor < origin floor < destination floor; elevator >>
                upQueue.insert(originFloor);
                upQueue.insert(destinationFloor);
            }
            else if (currentFloor > originFloor && currentFloor < destinationFloor) {
                //needs some logic with the requirements 2d array [[O, D], [O, D]...]
                addRequirements(originFloor, destinationFloor);
                downQueue.insert(originFloor);
                upQueue.insert(destinationFloor);
            }
            else { //origin floor < destination floor < current floor; elevator << and then >>
                downQueue.insert(originFloor);
                upQueue.insert(destinationFloor);
            }
        }
        else { //origin floor is above the destination floor (origin down to destination)
            if (currentFloor > originFloor) { //destination floor < origin floor < current floor; elevator <<
                downQueue.insert(originFloor);
                downQueue.insert(destinationFloor);
            }
            else if (currentFloor < originFloor && currentFloor > destinationFloor) {
                //needs some logic with the requirements 2d array [[O, D], [O, D]...]
                addRequirements(originFloor, destinationFloor);
                upQueue.insert(originFloor);
                downQueue.insert(destinationFloor);
            }
            else { //current floor < destination floor < origin floor; elevator >> and then <<
                upQueue.insert(originFloor);
                downQueue.insert(destinationFloor);
            }
        }

        // Determine whether the origin floor is above or below the current floor
        if (originFloor < currentFloor) {
            downQueue.insert(originFloor);  // Add to down queue if below the current floor
        } else {
            upQueue.insert(originFloor);    // Add to up queue if above the current floor
        }
    } 
    else if (receivedData[2] == 3) {
        // If packet type is 3, it's a ping response
        pingResponse = true;
    }
}


void ElevatorSubsystem::setCapacity(int cap) {
    if (cap > 5) {
        cap = 5;
    }
    else if (cap < 0) {
        cap = 0;
    }
    capacity = cap;
}

int ElevatorSubsystem::getCapacity() {
    return capacity;
}




