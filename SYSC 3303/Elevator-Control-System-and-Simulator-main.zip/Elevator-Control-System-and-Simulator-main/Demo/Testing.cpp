/**
 * Testing.cpp
 * This file contains the test cases for the Elevator System.
 * @author Ryan Page
 * @version 1.0
 */

#include <iostream>
#include <cassert>
#include "ElevatorSubsystem.cpp"
#include "ElevatorStatemachine.cpp"
#include "SchedulerSystem.cpp"
#include "SchedulerStatemachine.cpp"
#include "FloorSubsystem.cpp"
#include "Globals.cpp"
#include "InetHelpers.cpp"

bool testElevatorSubsystemInitialization() {
    ElevatorSubsystem elevatorSubsystem1(ELEVATOR1PORT);
    assert(elevatorSubsystem1.getCurrentFloor() == 1);
    assert(elevatorSubsystem1.getCompletedFloors().size() != 1);
    assert(elevatorSubsystem1.getDownQueue().size() == 0);
    assert(elevatorSubsystem1.getUpQueue().size() == 0);
    assert(elevatorSubsystem1.elevatorContext.getQueueSize() == 0);
    assert(elevatorSubsystem1.elevatorContext.getState() == ElevatorStates::STATIONARY);
    assert(elevatorSubsystem1.elevatorContext.getStatus() == false);

    ElevatorSubsystem elevatorSubsystem2(ELEVATOR2PORT);
    assert(elevatorSubsystem2.getCurrentFloor() == 1);
    assert(elevatorSubsystem2.getCompletedFloors().size() != 1);
    assert(elevatorSubsystem2.getDownQueue().size() == 0);
    assert(elevatorSubsystem2.getUpQueue().size() == 0);
    assert(elevatorSubsystem2.elevatorContext.getQueueSize() == 0);
    assert(elevatorSubsystem2.elevatorContext.getState() == ElevatorStates::STATIONARY);
    assert(elevatorSubsystem2.elevatorContext.getStatus() == false);

    ElevatorSubsystem elevatorSubsystem3(ELEVATOR4PORT);
    assert(elevatorSubsystem3.getCurrentFloor() == 1);
    assert(elevatorSubsystem3.getCompletedFloors().size() != 1);
    assert(elevatorSubsystem3.getDownQueue().size() == 0);
    assert(elevatorSubsystem3.getUpQueue().size() == 0);
    assert(elevatorSubsystem3.elevatorContext.getQueueSize() == 0);
    assert(elevatorSubsystem3.elevatorContext.getState() == ElevatorStates::STATIONARY);
    assert(elevatorSubsystem3.elevatorContext.getStatus() == false);

    ElevatorSubsystem elevatorSubsystem4(SCHEDULERPORT+4);
    assert(elevatorSubsystem4.getCurrentFloor() == 1);
    assert(elevatorSubsystem4.getCompletedFloors().size() != 1);
    assert(elevatorSubsystem4.getDownQueue().size() == 0);
    assert(elevatorSubsystem4.getUpQueue().size() == 0);
    assert(elevatorSubsystem4.elevatorContext.getQueueSize() == 0);
    assert(elevatorSubsystem4.elevatorContext.getState() == ElevatorStates::STATIONARY);
    assert(elevatorSubsystem4.elevatorContext.getStatus() == false);
    return true;
}

bool testSchedulerSystemInitialization() {
    SchedulerSystem schedulerSystem;
    assert(schedulerSystem.getRequestedFloors().size() == 0);
    assert(schedulerSystem.getScheduledRequests().size() == 0);
    return true;
}

bool testGoingToInvalidFloor_FromInputFile_1(){
    FloorSubsystem floorSubsystem1("test1.txt");
    assert(floorSubsystem1.getInvalidInput() == true);
    return true;
}

bool testGoingToInvalidFloor_FromInputFile_2(){
    FloorSubsystem floorSubsystem2("test2.txt");
    assert(floorSubsystem2.getInvalidInput() == true);
    return true;
}

bool testGoingToInvalidFloor_FromInputFile_3(){
    FloorSubsystem floorSubsystem2("test5.txt");
    assert(floorSubsystem2.getInvalidInput() == true);
    return true;
}

bool testGoingToInvalidFloor_FromInputFile_4(){
    FloorSubsystem floorSubsystem2("test6.txt");
    assert(floorSubsystem2.getInvalidInput() == true);
    return true;
}

bool testCapacityLimits() {
    ElevatorSubsystem elevatorSubsystem1(ELEVATOR1PORT);
    elevatorSubsystem1.setCapacity(5);
    elevatorSubsystem1.setCompletedFloors({1, 2, 3, 4, 5});
    elevatorSubsystem1.setCapacity(6); // Attempt to exceed capacity
    assert(elevatorSubsystem1.getCapacity() == 5); // Ensure capacity is capped at 5
    elevatorSubsystem1.setCapacity(3); // Set capacity to a valid number
    assert(elevatorSubsystem1.getCapacity() == 3); // Ensure capacity is set correctly
    elevatorSubsystem1.setCapacity(0); // Set capacity to 0
    assert(elevatorSubsystem1.getCapacity() == 0); // Ensure capacity is set to 0
    elevatorSubsystem1.setCapacity(-1); // Set capacity to a negative number
    assert(elevatorSubsystem1.getCapacity() == 0); // Ensure capacity is set to 0
    return true;
}

bool Testing_Ssystem(){
    FloorSubsystem floorSubsystem4("test3.txt");
    SchedulerSystem schedulerSystem4;
    ElevatorSubsystem elevatorSubsystem1(ELEVATOR1PORT);
    ElevatorSubsystem elevatorSubsystem2(ELEVATOR2PORT);
    ElevatorSubsystem elevatorSubsystem3(ELEVATOR3PORT);
    ElevatorSubsystem elevatorSubsystem4(ELEVATOR4PORT);
    floorSubsystem4.sendToScheduler();
    schedulerSystem4.takeRequests();
    schedulerSystem4.scheduleRequests();



    return true;
}

int main() {
    Testing = 1; //True
    bool allTestsPassed = true;
    bool Test1 = testElevatorSubsystemInitialization();
    bool Test2 = testSchedulerSystemInitialization();
    bool Test3 = testGoingToInvalidFloor_FromInputFile_1();
    bool Test4 = testGoingToInvalidFloor_FromInputFile_2();
    bool Test5 = testGoingToInvalidFloor_FromInputFile_3();
    bool Test6 = testGoingToInvalidFloor_FromInputFile_4();
    bool Test7 = Testing_Ssystem();
    bool Test8 = testCapacityLimits();
    
    std::cout << "_______________________________________________________________\n\n";
    std::cout << "Elevator System Testing (1 = Passed, 0 = Failed)" << std::endl;
    std::cout << "_______________________________________________________________\n";
    std::cout << "Test 1: ElevatorSubsystem Initialization: " << Test1 << std::endl;
    std::cout << "Test 2: SchedulerSystem Initialization: " << Test2 << std::endl;
    std::cout << "Test 3: Going to Invalid Floor from Input File 1: " << Test3 << std::endl;  
    std::cout << "Test 4: Going to Invalid Floor from Input File 2: " << Test4 << std::endl;  
    std::cout << "Test 5: Going to Invalid Floor from Input File 3: " << Test5 << std::endl;  
    std::cout << "Test 6: Going to Invalid Floor from Input File 4: " << Test6 << std::endl;  
    std::cout << "Test 7: Sending Request to Scheduler then Elevator and Back: " << Test7 << std::endl;
    std::cout << "Test 8: Testing Capacity Limits: " << Test8 << std::endl;
    allTestsPassed = Test1 && Test2  && Test3 && Test4 && Test5 && Test6 && Test8 && Test7;

     // Print the overall results
     std::cout << "\nOverall Test Results: " << (allTestsPassed ? "All Tests Passed" : "Some Tests Failed") << "\n";
     std::cout << "_______________________________________________________________\n";
     return 0;
}

