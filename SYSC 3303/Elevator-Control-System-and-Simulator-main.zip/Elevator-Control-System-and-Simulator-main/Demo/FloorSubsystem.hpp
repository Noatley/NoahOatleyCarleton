#ifndef FLOOR_SUBSYSTEM_HPP
#define FLOOR_SUBSYSTEM_HPP

#include "Globals.hpp"

class FloorSubsystem {
public:

    std::vector<std::queue<Person>> floors;
    std::priority_queue<RequestStructure, std::vector<RequestStructure>, RequestComparator> inputs;
    bool invalidInput = false;
    DatagramSocket receiveSocket;
    std::mutex inputLock;
    std::condition_variable inputcv;

    std::thread floorThread;
    DatagramSocket openSocket;

    FloorSubsystem(std::string fileName);
    bool sendToScheduler();
    void sendToScheduler_Testing();
    void openDoor(int floor);
    void receiveFromScheduler();
    void receiveFromScheduler_Testing();
    void runFloor();
    std::priority_queue<RequestStructure, std::vector<RequestStructure>, RequestComparator> getInputs();
    void setInputs(std::priority_queue<RequestStructure, std::vector<RequestStructure>, RequestComparator> in);
    bool getInvalidInput();
    void monitorOpen();
    void updateFloorStatus(sharedData* shared, const FloorStatus& new_status);
    void floorUpdate(int floor, bool open);



private:
    void parseFile(std::ifstream& inputFileStream);
    std::vector<uint8_t> parseRequest(RequestStructure request);
    std::chrono::milliseconds chronoConversion(std::string time);

    FloorStatus floorStatus;

    sharedData* shared;

    std::chrono::milliseconds initialTime;
    int endFloor;
};


#endif