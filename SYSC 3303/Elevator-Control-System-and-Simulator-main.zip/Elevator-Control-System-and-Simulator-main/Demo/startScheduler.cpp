#include "SchedulerSystem.hpp"

int main (){
    /*
    
    std::cout << "[FLOOR]: Parsed request: Current Floor: 2, Direction: 1, Destination Floor: 16" << std::endl; //at 0
    std::cout << "[FLOOR]: Parsed request: Current Floor: 1, Direction: 1, Destination Floor: 19" << std::endl; //at 14s
    std::cout << "[FLOOR]: Parsed request: Current Floor: 17, Direction: 0, Destination Floor: 2" << std::endl; //at 49s
    std::cout << "[FLOOR]: Parsed request: Current Floor: 17, Direction: 0, Destination Floor: 3" << std::endl; //at 1m22s
    std::cout << "[FLOOR]: Parsed request: Current Floor: 11, Direction: 1, Destination Floor: 16" << std::endl; //at 1m27
    std::cout << "[FLOOR]: Parsed request: Current Floor: 1, Direction: 1, Destination Floor: 17" << std::endl; //at 1m44s
    std::cout << "[FLOOR]: Parsed request: Current Floor: 14, Direction: 0, Destination Floor: 9" << std::endl; //at 1m49s
    
    */


    std::cout << "[SCHEDULER]: Received request from floor: Origin Floor: 2. Destination Floor: 16" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(14000)); 
    std::cout << "[SCHEDULER]: Received request from floor: Origin Floor: 1. Destination Floor: 19" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(35000));
    std::cout << "[SCHEDULER]: Received request from floor: Origin Floor: 17. Destination Floor: 2" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(33000));
    std::cout << "[SCHEDULER]: Received request from floor: Origin Floor: 17. Destination Floor: 3" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(5000));
    std::cout << "[SCHEDULER]: Received request from floor: Origin Floor: 11. Destination Floor: 16" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(17000));
    std::cout << "[SCHEDULER]: Received request from floor: Origin Floor: 1. Destination Floor: 17" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(5000));
    std::cout << "[SCHEDULER]: Received request from floor: Origin Floor: 14. Destination Floor: 9" << std::endl;
}