/**
 * Elevator subsytem implementation to simulate
 * a physical elevator system. Communicates with
 * FloorSubsystem and Scheduler implementations.
 * 
 * @author Andrew Rivera
 * @author Noah Oatley
 * @author Kyle Mathias
 * @author Ryan Page
 * @version 1.0 Iteration 1
 * Feb 1 8:25PM Nearly done
 */

#include <iostream>
#include <thread>
#include <chrono>
#include <random>
#include <iterator>
#include <algorithm>
#include <mutex>
#include <condition_variable>
#include <queue>
#include <fstream>
#include <sstream>
#include <assert.h>

#include "structure.hpp"

/**
 * Using data from iteration 0, assuming doorOpeningTime is roughly
 * the same as elevator unloading time, and doorOpenTime is roughly
 * the same as elevator loading time - elevator unloading time. 
 * 
 * Opening time is because the stop watch timer was started
 * as soon as the doors started to open and was stopped seconds after
 * we left the elevator without delay. 
 * 
 * Open time is assumed as such because the timer began as 
 * soon as the elevator doors started to open and stopped 
 * as soon as it completely closed. 
 * 
*/

const int doorOpeningTime = 3608; //3608ms
const int doorOpenTime = 8422 - doorOpeningTime;//4814ms
const int elevatorStoppingTime = 9030; //9030ms
const int elevatorTravelTime = 1314; //1314ms Average travel time between two floors at top speed
const int elevatorStartTime = 4470; //4470ms Average acceleration time
struct ElevatorStructure elevStruct;

//scheduler locks
std::mutex schedulerLock; //lock for passing request structures from floor to scheduler
std::condition_variable_any cond;

//elevator locks
std::mutex elevatorLock; //lock for passing request structures from scheduler to elevator
std::condition_variable_any eleCond;

//pickup locks
std::mutex pickLock; //lock for passing back floor numbers of completed floors
std::condition_variable pickCond;

//global storage arrays
std::queue<struct RequestStructure> requests; //requests from floor to scheduler and back
std::queue<struct RequestStructure> elevatorQueue; //requests from scheduler to elevator and back
std::set<int> pickups; //elevator notifies scheduler of which floor was just picked up, scheduler notifies floor to empty its queue
std::set<int> finishedFloors; //send to floor

//class for elevator subsystem
class ElevatorSubsystem {
private:
    std::set<int> upQueue;   //queues for elevator direction
    std::set<int> downQueue; 
    std::set<int> completedFloors; //queue of the completed floors to be sent back to floorSubsystem
    int currentFloor = elevStruct.currentFloor; //current floor that the elevator is on, default to 1
    bool direction = elevStruct.travelDirection; //true = up, false = down

public:
    //ELEVATOR->SCHEDULER
    void sendToScheduler(){ //sends the completed floors to scheduler 
        std::unique_lock<std::mutex> lock(pickLock); //pickLock to be used as shared mutex

        if (pickCond.wait_until(lock, std::chrono::steady_clock::now() + std::chrono::milliseconds(500), [this] { return !completedFloors.empty(); })) { //wait for at least one floor to be completed, timeout after 500ms
            while (!completedFloors.empty()) {
                int value = *completedFloors.begin(); //dump all completed floors to global pickups set
                pickups.insert(value);
                completedFloors.erase(value);
            }
            pickCond.notify_all(); //unlock
        }
    }

    //SCHEDULER->ELEVATOR
    void receiveFromScheduler() { //receives new requests from scheduler
        std::unique_lock<std::mutex> lock(elevatorLock); //elevatorLock is shared mutex

        if (eleCond.wait_until(lock, std::chrono::steady_clock::now() + std::chrono::milliseconds(500), [this] { return !elevatorQueue.empty(); })) { //wait for at least one request to come in, timeout after 500ms
            while (!elevatorQueue.empty()) { //loop until no more new requests
                RequestStructure request = elevatorQueue.front(); //grab front request
                elevatorQueue.pop();

                //assign request to upQueue or downQueue based on direction
                if (request.direction) { 
                    upQueue.insert(request.originFloor);
                    upQueue.insert(request.destination);
                } else { 
                    downQueue.insert(request.originFloor);
                    downQueue.insert(request.destination);
                }
            }
            eleCond.notify_all(); 
        }
    }

    //main thread function to run the elevator
    void runElevator() {
        while (true) {
            receiveFromScheduler(); //fetch new requests

            if (upQueue.empty() && downQueue.empty()) {
                std::unique_lock<std::mutex> lock(elevatorLock); //elevatorLock is shared mutex
                eleCond.wait(lock, [this] { return !upQueue.empty() || !downQueue.empty(); }); //if no pending floor requests, sleep until at least one
            }

            if (direction) { //moving up
                while (!upQueue.empty()) { //empty whole upQueue
                    int nextFloor = *upQueue.begin(); //grab next floor in order
                    if (nextFloor > currentFloor) {
                        moveToFloor(nextFloor); //move to the next floor
                        upQueue.erase(nextFloor);
                        completedFloors.insert(nextFloor); //add arrived floor to completed list
                    } 
                    else if (nextFloor == currentFloor) { //if elevator is already on this floor
                        std::cout << "Elevator is already on floor " << currentFloor << ". Handling request." << std::endl; 
                        upQueue.erase(nextFloor); //skip and head to next floor
                        completedFloors.insert(nextFloor);
                    } 
                    else {
                        break; //no more floors in the current direction
                    }
                }
                //switch direction if no more requests in the current direction
                if (upQueue.empty() && !downQueue.empty()) {
                    direction = false;
                }
            } 
            else { //moving down
                while (!downQueue.empty()) {
                    int nextFloor = *downQueue.rbegin(); //start at other end of set
                    if (nextFloor < currentFloor) {
                        moveToFloor(nextFloor); //move to next lower floor
                        downQueue.erase(nextFloor);
                        completedFloors.insert(nextFloor); //add arrived floor to completed list
                    } 
                    else if (nextFloor == currentFloor) { //if elevator is already on this floor
                        std::cout << "Elevator is already on floor " << currentFloor << ". Handling request." << std::endl;
                        downQueue.erase(nextFloor); //skip and head to next floor
                        completedFloors.insert(nextFloor);
                    } 
                    else {
                        break; //no more floors in the current direction
                    }
                }
                //switch direction if no more requests in the current direction
                if (downQueue.empty() && !upQueue.empty()) {
                    direction = true;
                }
            }

            sendToScheduler(); //notify scheduler of completed floors
        }
    }


    //getters for the test files
    std::set<int> getUpQueue() {
        return upQueue;
    }

    std::set<int> getDownQueue() {
        return downQueue;
    }
    
    int getCurrentFloor() const {
        return currentFloor;
    }

    std::set<int> getCompletedFloors() {
        return completedFloors;
    }


    //setters for test files
    void setCompletedFloors(std::set<int> completed) {
        completedFloors = completed;
    }

private:
    void moveToFloor(int newFloor) { //function to output elevator movement and change floor
        if (currentFloor != newFloor) {
            std::cout << "Moving from " << currentFloor << " to " << newFloor << std::endl;
            std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime));
            currentFloor = newFloor; //elevator is now on new floor
            std::cout << "Elevator arrived at floor " << currentFloor << std::endl;
        }
    }
};


//class for floor subsystem
class FloorSubsystem {
    private:
        std::vector<std::queue<Person>> floors; //vector of queues of Person structs, vector represents floors in building, queue holds Person structs waiting at each floor
        std::priority_queue<RequestStructure> inputs; //inputs to be sent to the scheduler

    public:
        FloorSubsystem(std::string fileName) { //constructor needs to grab input file data and store it to create inputs
            floors.resize(numFloors); //resize the floors vector to the max number of floors
            std::ifstream inputFile(fileName); //initialize ifstream for input file
            assert(inputFile.is_open()); //make sure file exists
            parseFile(inputFile); //run the parse method to interpret file contents
            inputFile.close(); //close file
        }

        //FLOOR->SCHEDULER
        void sendToScheduler() { //send floorrequests to scheduler
            std::unique_lock<std::mutex> lock(schedulerLock); //shares mutex schedulerLock

            if (cond.wait_until(lock, std::chrono::steady_clock::now() + std::chrono::milliseconds(500), [this] { return !inputs.empty(); })) { //wait until theres requests in the internal input queue, or timeout after 500ms
                while (!inputs.empty()) { //loop until internal inputs queue empty
                    requests.push(inputs.top()); //dump local inputs to global requests
                    Person person = Person(inputs.top().destination, inputs.top().direction); //create a new Person object 
                    floors[inputs.top().originFloor].push(person); //add the person to the floor
                    inputs.pop(); 
                }
                cond.notify_all(); //unlock
            }
        }

        //SCHEDULER->FLOOR
        void receiveFromScheduler() { 
            std::unique_lock<std::mutex> lock(pickLock); //shares mutex pickLock

            if (pickCond.wait_until(lock, std::chrono::steady_clock::now() + std::chrono::milliseconds(500), [this] { return !finishedFloors.empty(); })) { //wait until theres finished floors globally or timeout 500ms
                while (!finishedFloors.empty()) { //iterate through each finished floor
                    int value = *finishedFloors.begin();
                    while (!floors[value - 1].empty()) { //value - 1 because vector starts floor 1 from index 0 so index = floor - 1
                        floors[value - 1].pop(); //remove all people at that floor (theyre in the elevator or got off at that floor already)
                    }
                    finishedFloors.erase(value); 
                }
                pickCond.notify_all(); //unlock
            }
        }

        //main thread function to run the floor
        void runFloor() {
            while (true) {
                sendToScheduler();   //send floor requests to Scheduler
                receiveFromScheduler(); //receive completed floors

                std::this_thread::sleep_for(std::chrono::milliseconds(100)); 
            }
        }



        //getters
        std::priority_queue<RequestStructure> getInputs() {
            return inputs;
        }


        //setters
        void setInputs(std::priority_queue<RequestStructure> in) {
            inputs = in;
        }


    private:
        void parseFile(std::ifstream& inputFileStream) { //function for reading input filestream from file and extracting its contents to a RequestStructure
            std::string line; //string to extract each line

            while(std::getline(inputFileStream, line)) {
                std::stringstream ss(line); //create stringstream from line
                std::string timeStr, dirStr; //variables to extract information from
                std::chrono::milliseconds time;
                unsigned curr, dest;
                bool dir;
                
                ss >> timeStr >> curr >> dirStr >> dest; //if the input is formatted properly, all variables should be initialized properly

                time = chronoConversion(timeStr); //convert time to ms

                if (dirStr == "Up" || dirStr == "up") { //get directions from the string
                    dir = true;
                }
                else if (dirStr == "Down" || dirStr == "down") {
                    dir = false;
                }
                else {
                    throw std::invalid_argument("Wrong direction");
                }

                RequestStructure input(time, curr, dest, dir); //create request structure with these variables

                inputs.push(input); //add requeststructure to internal inputs

                //debug just to see data from input
                //std::cout << "Current Floor: " << input.originFloor << ", Direction: " << input.direction << ", Destination Floor: " << input.destination << std::endl;
            }
        }

        std::chrono::milliseconds chronoConversion(std::string time) { //function to take entire time string and convert to ms
            int hours, minutes, seconds, milliseconds;
            char colon, period;

            std::istringstream timeStream(time); //create stringstream from time
            timeStream >> hours >> colon >> minutes >> colon >> seconds >> period >> milliseconds; //if formatted correctly, should fit into all variables

            return std::chrono::hours(hours) + std::chrono::minutes(minutes) + std::chrono::seconds(seconds) + std::chrono::milliseconds(milliseconds); //add up converted times and return
        }
};


//class for scheduler system
class SchedulerSystem {
private:
    std::set<int> RequestedFloors; //floors from floor to elevator
    std::set<int> completedFloors; //receive from elevator and send to floor
    std::queue<struct RequestStructure> scheduledRequests; //internal queue to store the requests in, so only 1 lock needs to be held

public:
    //FLOOR->SCHEDULER
    void takeRequests() { //add global requests to internal request queue (receive requests from floor)
        std::unique_lock<std::mutex> lock(schedulerLock); //share mutex schedulerLock

        if (cond.wait_until(lock, std::chrono::steady_clock::now() + std::chrono::milliseconds(500), [] { return !requests.empty(); })) { //wait until new request from floor or timeout 500ms
            while (!requests.empty()) {
                scheduledRequests.push(requests.front()); //add requests from floor to internal queue
                requests.pop();
            }
            cond.notify_all(); //unlock
        }
    }

    //SCHEDULER->ELEVATOR
    void sendRequests() { //send internal request queue to elevator
        std::unique_lock<std::mutex> lock(elevatorLock); //shared mutex elevatorLock

        if (eleCond.wait_until(lock, std::chrono::steady_clock::now() + std::chrono::milliseconds(500), [this] { return !scheduledRequests.empty(); })) { //wait until input from floor has come in or timeout 500ms
            while (!scheduledRequests.empty()) {
                elevatorQueue.push(scheduledRequests.front()); //send them from internal scheduledReqests to global elevatorQueue
                scheduledRequests.pop();
            }
            eleCond.notify_all(); 
        }
    }

    //ELEVATOR->SCHEDULER
    void getCompleted() { //get completed floors from elevator
        std::unique_lock<std::mutex> lock(pickLock);

        if (pickCond.wait_until(lock, std::chrono::steady_clock::now() + std::chrono::milliseconds(500), [] { return !pickups.empty(); })) { //wait until at least 1 floor completed or timeout 500ms
            while (!pickups.empty()) {
                int value = *pickups.begin(); //add completed floor to internal set
                completedFloors.insert(value);
                pickups.erase(value);
            }
            pickCond.notify_all(); 
        }
    }

    //SCHEDULER->FLOOR
    void notifyFloors() { //clear floors that got picked up
        std::unique_lock<std::mutex> lock(pickLock); //shared mutex pickLock

        if (pickCond.wait_until(lock, std::chrono::steady_clock::now() + std::chrono::milliseconds(500), [this] { return !completedFloors.empty(); })) { //wait until received and saved at least one completed floor from elevator or timeout 500ms
            while (!completedFloors.empty()) {
                int value = *completedFloors.begin(); //send completed floor to global finished floors
                finishedFloors.insert(value);
                completedFloors.erase(value);
            }
            pickCond.notify_all(); 
        }
    }


    //getters
    std::queue<struct RequestStructure> getScheduledRequests (){
        return scheduledRequests;
    }

    std::set<int> getRequestedFloors () {
        return RequestedFloors;
    }

    std::set<int> getCompletedFloors () {
        return completedFloors;
    }


    //setters
    void setScheduledRequests (std::queue<struct RequestStructure> sch){
        scheduledRequests = sch;
    }

    void setRequestedFloors (std::set<int> req) {
        RequestedFloors = req;
    }

    void setCompletedFloors (std::set<int> com) {
        completedFloors = com;
    }


    //main thread function to run the scheduler
    void runScheduler() {
        while (true) {
            takeRequests();  //receive requests from Floor
            sendRequests();  //send requests to Elevator
            getCompleted();  //get completed floors from Elevator
            notifyFloors();  //notify Floor of completed pickups

            std::this_thread::sleep_for(std::chrono::milliseconds(100)); 
        }
    }
};

/**
int main() {
    FloorSubsystem floor("input.txt"); 
    SchedulerSystem scheduler;
    ElevatorSubsystem elevator;

    std::thread floorThread(&FloorSubsystem::runFloor, &floor);
    std::thread schedulerThread(&SchedulerSystem::runScheduler, &scheduler);
    std::thread elevatorThread(&ElevatorSubsystem::runElevator, &elevator);

    floorThread.join();
    schedulerThread.join();
    elevatorThread.join();

    std::cout << "main end";

    return 0;
}

 */
