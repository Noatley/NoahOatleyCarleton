#ifndef STRUCTURE_HPP
#define STRUCTURE_HPP

#include <iostream>
#include <set>
#include <map>
#include <ctime>

const int numFloors = 20;
const std::string inputFileName = "input.txt";

struct ElevatorStructure {

    bool elevatorEnabled = false; //true if in motion, false if not in motion
    bool travelDirection = true; //true if going up, false if going down
    bool floorRequested = false; //true if button was pressed for this floor, false if there is no request
    std::map<int, bool> light; //key = floor#, value = boolean true or false to indicate light
    int currentFloor = 1;
    int destinationFloor = 1;
    int initialFloor = 3;
    std::set<int>inputFile;
};

//input format
//"hh:mm:ss.mmm n 'up/down' n"
struct RequestStructure { 
    std::chrono::milliseconds time;
    unsigned originFloor; //NOTE indexable data types like vector start indexing at 0 so floor n will be at index n - 1
    unsigned destination; 
    bool direction;

    RequestStructure(std::chrono::milliseconds t, unsigned f, unsigned de, bool di) : time(t), originFloor(f), destination(de), direction(di) {}

    bool operator<(const RequestStructure& other) const {
        return time < other.time;  
    }
};

struct Person {
    unsigned destination;
    bool direction;

    Person(unsigned dest, bool dir) : destination(dest), direction(dir) {}
};

#endif