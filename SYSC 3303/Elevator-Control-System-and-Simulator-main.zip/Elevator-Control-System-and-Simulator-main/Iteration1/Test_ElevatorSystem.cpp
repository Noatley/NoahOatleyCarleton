/**
 * @file Test_ElevatorSystem.cpp
 * @author Ryan Page
 * @author Andrew Rivera
 * @version 1.0 Iteration 1
 * Feb 1 9:03PM Not done yet
 */
#include <iostream> 
#include "ElevatorSystem.cpp"

// Tests floor to scheduler interaction
bool Test_FloorToScheduler(){
    // Creates SchedulerSystem and ElevatorSubsystem
    SchedulerSystem scheduler;
    FloorSubsystem floor(inputFileName);

    std::queue<struct RequestStructure> requests;
    std::priority_queue<RequestStructure> inputs;

    // Simulates sending a request from the scheduler to the elevator
    RequestStructure request(std::chrono::milliseconds(0), 2, 5, true); // Request from floor 2 to 5, going up
    inputs.push(request);
    floor.setInputs(inputs);

    floor.sendToScheduler();

    scheduler.takeRequests();

    if (scheduler.getScheduledRequests().empty()) {
        return false; // Request was not passed to the scheduler
    }

    // Checks if the request was passed to the elevator
    RequestStructure receivedRequest = scheduler.getScheduledRequests().front();
    if (receivedRequest.originFloor != 2 || receivedRequest.destination != 5 || receivedRequest.direction != true) {
        return false; // Request data is incorrect
    }

    return true; // Test passed
}

//Tests scheduler to elevator interaction
bool Test_SchedulerToElevator(){

    // Creates SchedulerSystem and ElevatorSubsystem
    SchedulerSystem scheduler;
    ElevatorSubsystem elevator;

    std::queue<struct RequestStructure> elevatorQueue;

    // Simulates sending a request from the scheduler to the elevator
    std::queue<struct RequestStructure> scheduled = scheduler.getScheduledRequests();
    RequestStructure request(std::chrono::milliseconds(0), 2, 5, true); // Request from floor 2 to 5, going up
    scheduled.push(request);
    scheduler.setScheduledRequests(scheduled);

    scheduler.sendRequests();

    elevator.receiveFromScheduler();

    // Checks if the request was passed to the elevator
    elevator.receiveFromScheduler();
    if (elevator.getUpQueue().empty()) {
        return false; // Request was not passed to the elevator
    }

    int nextFloor = *elevator.getUpQueue().begin();
    if (nextFloor != 2 && nextFloor != 5) {
        return false; // Request data is incorrect
    }

    return true; // Test passed

}

//Tests elevator to scheduler interaction
bool Test_ElevatorToScheduler() {
    // Creates ElevatorSubsystem and SchedulerSystem
    ElevatorSubsystem elevator;
    SchedulerSystem scheduler;

    std::set<int> pickups; // Buffer between ElevatorSubsystem and SchedulerSystem

    // Simulates completing a floor in the elevator
    std::set<int> completed = elevator.getCompletedFloors(); // Floor 2 was completed
    completed.insert(2);
    elevator.setCompletedFloors(completed);

    elevator.sendToScheduler();

    // Simulate the scheduler receiving the completed floor
    scheduler.getCompleted();

    // Checks if the completed floor was passed to the scheduler (indirectly)
    if (scheduler.getCompletedFloors().empty()) {
        return false; // Completed floor was not passed to the scheduler
    }

    int completedFloor = *scheduler.getCompletedFloors().begin();
    if (completedFloor != 2) {
        return false; // Completed floor data is incorrect
    }

    return true; // Test passed

}

//Tests scheduler to floor interaction
bool Test_SchedulerToFloor() {
    // Creates SchedulerSystem and FloorSubsystem
    SchedulerSystem scheduler;
    FloorSubsystem floor(inputFileName);

    std::set<int> finishedFloors;

    // Simulates notifying the floor of a completed pickup
    std::set<int> completed = scheduler.getCompletedFloors();
    completed.insert(2); // Floor 2 was completed
    scheduler.setCompletedFloors(completed);

    scheduler.notifyFloors();

    floor.receiveFromScheduler();

    // Checks if the floor subsystem received the notification (indirectly)
    if (!finishedFloors.empty()) {
        return false; // Notification was not passed to the floor
    }

    return true; // Test passed
}


int main() {
    bool allTestsPassed = true; // Keeps track of overall test status

    // Runs each test and store results in variables
    bool floorToSchedulerResult = Test_FloorToScheduler();
    bool schedulerToElevatorResult = Test_SchedulerToElevator();
    bool elevatorToSchedulerResult = Test_ElevatorToScheduler();
    bool schedulerToFloorResult = Test_SchedulerToFloor();

    // Print the results at the end
    std::cout << "_______________________________________________________________\n";
    std::cout << "Floor -> Scheduler Interaction Test: " << (floorToSchedulerResult ? "Passed" : "Failed") << "\n";
    std::cout << "Scheduler -> Elevator Interaction Test: " << (schedulerToElevatorResult ? "Passed" : "Failed") << "\n";
    std::cout << "Elevator -> Scheduler Interaction Test: " << (elevatorToSchedulerResult ? "Passed" : "Failed") << "\n";
    std::cout << "Scheduler -> Floor Interaction Test: " << (schedulerToFloorResult ? "Passed" : "Failed") << "\n";
    std::cout << "_______________________________________________________________\n";
    
    // Accumulate the overall result based on individual tests
    allTestsPassed &= floorToSchedulerResult;
    allTestsPassed &= schedulerToElevatorResult;
    allTestsPassed &= elevatorToSchedulerResult;
    allTestsPassed &= schedulerToFloorResult;

    // Print the overall results
    std::cout << "Overall Test Results: " << (allTestsPassed ? "All Tests Passed" : "Some Tests Failed") << "\n";
    std::cout << "_______________________________________________________________\n";
    return 0;
}
