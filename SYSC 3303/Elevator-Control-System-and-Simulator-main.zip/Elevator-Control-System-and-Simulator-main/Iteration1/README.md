## Elevator-Control-System-and-Simulator
Term project for SYSC3303 Iteration 1:
- Andrew Rivera 101192264 
- Kyle Mathias 101266139
- Ryan Page 101268082
- Kael Lascelle 101269383
- Noah Oatley 101189707

## Files:
**ElevatorSystem.cpp** - Implementation of floor, elevator and scheduler subsytems.

**run.cpp** - Implementation of the main function to run the threads. 
**run.exe** - Executable for run.cpp

**structure.hpp** - Header file with the used structures, constants and other includes.

**Test_ElevatorSystem.cpp** - Test implementation of the subsystem interactions.

**Test_ElevatorSystem.exe** - Executable for Test_ElevatorSystem.cpp.

**UML Class Diagram.png**
**UML Sequence Diagram.png**

**input.txt** - Sample input

## How to run
Option 1:
- Run executable files using ./run or ./Test_ElevatorSystem

Option 2:
  1. Compile Test_ElevatorSystem and ElevatorSystem cpp files:
      - g++ -o run ElevatorSystem.cpp
      - g++ -o Test_ElevatorSystem Test_ElevatorSystem.cpp
      
  2. Run executable files using ./run and ./Test_ElevatorSystem
