#ifndef FLOOR_SUBSYSTEM_HPP
#define FLOOR_SUBSYSTEM_HPP

#include "Globals.hpp"

class FloorSubsystem {
private:
    std::vector<std::queue<Person>> floors;
    std::priority_queue<RequestStructure, std::vector<RequestStructure>, RequestComparator> inputs;
    bool invalidInput = false;
    DatagramSocket receiveSocket;
    std::mutex inputLock;
    std::condition_variable inputcv;
    std::chrono::milliseconds initialTime;

    std::thread floorThread;
    DatagramSocket openSocket;

public:
    FloorSubsystem(std::string fileName);
    bool sendToScheduler();
    void openDoor(int floor);
    void receiveFromScheduler();
    void runFloor();
    std::priority_queue<RequestStructure, std::vector<RequestStructure>, RequestComparator> getInputs();
    void setInputs(std::priority_queue<RequestStructure, std::vector<RequestStructure>, RequestComparator> in);
    bool getInvalidInput();
    void monitorOpen();



private:
    void parseFile(std::ifstream& inputFileStream);
    std::vector<uint8_t> parseRequest(RequestStructure request);
    std::chrono::milliseconds chronoConversion(std::string time);
};


#endif