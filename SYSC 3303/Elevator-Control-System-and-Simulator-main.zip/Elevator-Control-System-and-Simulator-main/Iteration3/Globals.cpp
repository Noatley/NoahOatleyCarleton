#include "Globals.hpp"






//!!!May not need these anymore past iteration 3!!!
// Define global variables
std::queue<struct RequestStructure> requests;
std::queue<struct RequestStructure> elevatorQueue;
std::set<int> pickups;
std::set<int> finishedFloors;

// Define global mutexes and condition variables
std::mutex schedulerLock;
std::condition_variable_any cond;
std::mutex elevatorLock;
std::condition_variable_any eleCond;
std::mutex pickLock;
std::condition_variable pickCond;

