#ifndef ELEVATOR_SUBSYSTEM_HPP
#define ELEVATOR_SUBSYSTEM_HPP

#include "Globals.hpp"
#include "ElevatorStatemachine.hpp"

class ElevatorSubsystem {
private:
    std::set<int> upQueue;
    std::set<int> downQueue;
    std::set<int> completedFloors;
    int currentFloor;
    int elevatorID;
    bool direction;
    int internal_port;
    int capacity;

    bool openResponse;
    bool pingResponse;

    DatagramSocket elevatorSocket;
    std::thread listenerThread;
    std::thread sendThread;

    std::set<int> pickupQueue; 
    std::set<int> dropoffQueue; 



public:
    ElevatorContext elevatorContext;
    ElevatorSubsystem(int port);
    void sendToScheduler();
    void createThreads();
    void receiveFromScheduler();
    void runElevator();
    std::set<int> getUpQueue();
    std::set<int> getDownQueue();
    int getCurrentFloor() const;
    int getElevatorID() const;
    bool getDirection();
    std::set<int> getCompletedFloors();
    void setCompletedFloors(std::set<int> completed);
    void moveUp();
    void moveDown();
    void openDoors();

private:
    void moveToFloor(int newFloor);
};

#endif