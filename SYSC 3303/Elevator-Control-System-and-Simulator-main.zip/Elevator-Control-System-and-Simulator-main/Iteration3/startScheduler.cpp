#include "SchedulerSystem.hpp"

int main (){
    SchedulerSystem scheduler;

    std::thread schedulerThread(&SchedulerSystem::runScheduler, &scheduler);

    schedulerThread.join();
}