#include "FloorSubsystem.hpp"

FloorSubsystem::FloorSubsystem(std::string fileName) : receiveSocket(FLOORPORT), openSocket(OPENPORT) { //constructor needs to grab input file data and store it to create inputs
    floors.resize(numFloors); //resize the floors vector to the max number of floors
    std::ifstream inputFile(fileName); //initialize ifstream for input file
    assert(inputFile.is_open()); //make sure file exists
    parseFile(inputFile); //run the parse method to interpret file contents
    inputFile.close(); //close file
    floorThread = std::thread(&FloorSubsystem::monitorOpen, this);
}

void FloorSubsystem::monitorOpen() {
    while (true) {
        std::vector<uint8_t> data = receiveFromSubsystem(openSocket);

        assert (data[0] == 0); //check if the data is meant to be for the floor

        if (data[2] == 2){ //Packet type = 2, scheduler tells floor to open door
            openDoor(data[1]);
        }
    }
    
}

//FLOOR->SCHEDULER
bool FloorSubsystem::sendToScheduler() { //send floorrequests to scheduler
    if (!inputs.empty()) { //wait until theres requests in the internal input queue, or timeout after 500ms
        std::this_thread::sleep_for(std::chrono::milliseconds(abs(initialTime - inputs.top().time)));
        initialTime = inputs.top().time;
        std::vector<uint8_t> requestData = parseRequest(inputs.top());
        sendToSubsystem(SCHEDULERFLOORPORT, requestData); //send the request to the scheduler
        inputs.pop(); 
        return true;
    } else {
        return false;
    }
}

//SCHEDULER->FLOOR
void FloorSubsystem::receiveFromScheduler() { 
    std::vector<uint8_t> data = receiveFromSubsystem(receiveSocket); //receive data from scheduler

    assert (data[0] == 0); //check if the data is meant to be for the floor

    if (data[2] == 1){ //Packet type = 1, scheduler notifies floor that elevator has arrived at that floor.
        std::cout << "[FLOOR]: Elevator detected on floor: " << static_cast<int>(data[3]) << std::endl;
    }
}

void FloorSubsystem::openDoor(int floor) {
    std::cout << "[FLOOR]: Opening door on floor " << floor <<"." << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(5)); //Simulate door opening
    std::cout << "[FLOOR]: Closing door on floor " << floor << "." << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(5)); //Simulate door closing
}

//main thread function to run the floor
void FloorSubsystem::runFloor() {
    while (true) {
        if (sendToScheduler()) {   //send floor requests to Scheduler
            receiveFromScheduler(); //receive completed floors
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(100)); 
    }
}

//getters
std::priority_queue<RequestStructure, std::vector<RequestStructure>, RequestComparator> FloorSubsystem::getInputs() {
    return inputs;
}

//setters
void FloorSubsystem::setInputs(std::priority_queue<RequestStructure, std::vector<RequestStructure>, RequestComparator> in) {
    inputs = in;
}

void FloorSubsystem::parseFile(std::ifstream& inputFileStream) { //function for reading input filestream from file and extracting its contents to a RequestStructure
    std::string line; //string to extract each line

    while(std::getline(inputFileStream, line)) {
        std::stringstream ss(line); //create stringstream from line
        std::string timeStr, dirStr; //variables to extract information from
        std::chrono::milliseconds time;
        int curr, dest;
        bool dir;
            ss >> timeStr >> curr >> dirStr >> dest; //if the input is formatted properly, all variables should be initialized properly

        if(dest < 1 || dest > numFloors || curr < 1 || curr > numFloors){ //check if the floor is valid{
            invalidInput = true;
        }else{

            time = chronoConversion(timeStr); //convert time to ms
    
            if (dirStr == "Up" || dirStr == "up") { //get directions from the string
                dir = true;
            }
            else if (dirStr == "Down" || dirStr == "down") {
                dir = false;
            }
            else {
                throw std::invalid_argument("Wrong direction");
            }
    
            RequestStructure input(time, curr, dest, dir); //create request structure with these variables
    
            inputs.push(input); //add requeststructure to internal inputs
    
            //debug just to see data from input
            std::cout << "[FLOOR]: Parsed request: Current Floor: " << input.originFloor << ", Direction: " << input.direction << ", Destination Floor: " << input.destination << std::endl;    
        }
    }

    initialTime = inputs.top().time;
}

std::vector<uint8_t> FloorSubsystem::parseRequest(RequestStructure request) { //function to parse request structure into a vector of bytes
    std::vector<uint8_t> data; //initialize vector of bytes
    data.push_back(0); //add floor identifier to data as 0
    data.push_back(request.originFloor); //add origin floor to data
    data.push_back(0); //add packet type identifier to data as 0
    data.push_back(request.destination); //add destination to data
    return data; //return data
}

std::chrono::milliseconds FloorSubsystem::chronoConversion(std::string time) { //function to take entire time string and convert to ms
    int hours, minutes, seconds, milliseconds;
    char colon, period;

    std::istringstream timeStream(time); //create stringstream from time
    timeStream >> hours >> colon >> minutes >> colon >> seconds >> period >> milliseconds; //if formatted correctly, should fit into all variables

    return std::chrono::hours(hours) + std::chrono::minutes(minutes) + std::chrono::seconds(seconds) + std::chrono::milliseconds(milliseconds); //add up converted times and return
}

bool FloorSubsystem::getInvalidInput() {
    return invalidInput;
}