#include "FloorSubsystem.hpp"

int main (){
    FloorSubsystem floor("input.txt");

    std::thread floorThread(&FloorSubsystem::runFloor, &floor);

    floorThread.join();

}
