#include "ElevatorSubsystem.hpp"
#include "FloorSubsystem.hpp"
#include "SchedulerSystem.hpp"
#include "Globals.hpp"

int main() {
    FloorSubsystem floor("input.txt"); 
    SchedulerSystem scheduler;

    std::vector<ElevatorSubsystem> elevators;
    std::vector<std::thread> elevatorThreads;

    ElevatorSubsystem elevator1(ELEVATOR1PORT);
    ElevatorSubsystem elevator2(ELEVATOR2PORT);
    ElevatorSubsystem elevator3(ELEVATOR3PORT);
    ElevatorSubsystem elevator4(ELEVATOR4PORT);
    
    std::thread floorThread(&FloorSubsystem::runFloor, &floor);

    std::thread schedulerThread(&SchedulerSystem::runScheduler, &scheduler);

    std::thread elevatorThread1(&ElevatorSubsystem::runElevator, &elevator1);
    std::thread elevatorThread2(&ElevatorSubsystem::runElevator, &elevator2);
    std::thread elevatorThread3(&ElevatorSubsystem::runElevator, &elevator3);
    std::thread elevatorThread4(&ElevatorSubsystem::runElevator, &elevator4);
    
    floorThread.join();
    schedulerThread.join();
    elevatorThread1.join();
    elevatorThread2.join();
    elevatorThread3.join();
    elevatorThread4.join();

    std::cout << "main end" << std::endl;

    return 0;
}
