#include "ElevatorSubsystem.hpp"
#include "ElevatorStatemachine.hpp"

ElevatorSubsystem::ElevatorSubsystem(int port) : currentFloor(1), direction(true), elevatorSocket(port), internal_port(port), elevatorID(port - OFFSET), pingResponse(false), openResponse(true), capacity(0), completedFloors() {}

//ELEVATOR->SCHEDULER
void ElevatorSubsystem::sendToScheduler() {
    while (true) {
        if (!completedFloors.empty()) {
            while (!completedFloors.empty()) {
                int value = *completedFloors.begin();
                pickups.insert(value);
                completedFloors.erase(value);
                std::vector<uint8_t> responseData;
                responseData.push_back(1); //Identifier, 1 indicates it is from ElevatorSubsystem
                responseData.push_back(static_cast<uint8_t>(elevatorID)); //Elevator ID, indicates which elevator car
                responseData.push_back(1); //Packet Type, 1 indicates that elevator arrived at floor
                responseData.push_back(static_cast<uint8_t>(currentFloor)); //Notification, scheduler does not care
                sendToSubsystem(SCHEDULERPORT, responseData); //send the request to the scheduler
            }
        } 
        else if (pingResponse) {
            pingResponse = false;
            std::vector<uint8_t> responseData;
            responseData.push_back(1);
            responseData.push_back(elevatorID);
            responseData.push_back(4);
            responseData.push_back(direction == true ? 1 : 0);
            responseData.push_back(currentFloor);
            responseData.push_back(capacity);

            sendToSubsystem(SCHEDULEROFFSET + elevatorID, responseData);
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}


void ElevatorSubsystem::createThreads() {
        sendThread = std::thread(&ElevatorSubsystem::sendToScheduler, this);
        listenerThread = std::thread(&ElevatorSubsystem::receiveFromScheduler, this);
}

//SCHEDULER->ELEVATOR
void ElevatorSubsystem::receiveFromScheduler() {
    while(true) { // Loop to receive data
        std::vector<uint8_t> receivedData = receiveFromSubsystem(elevatorSocket);
        assert(elevatorID == receivedData[1]);  // Ensure correct elevator ID

        if (receivedData[2] == 2) {
            // If the packet type is 2, it indicates that the elevator has arrived at the floor and is ready to open doors
            openDoors();
        } 
        else if (receivedData[2] == 0) {  // Packet type 0 indicates a new floor request
            int requestedFloor = receivedData[3];
            bool isPickup = (receivedData[4] == 1);  // If 1, it's a pickup; if 0, it's a dropoff

            // Determine whether the requested floor is above or below the current floor
            if (requestedFloor < currentFloor) {
                downQueue.insert(requestedFloor);  // Add to down queue if below the current floor
            } else {
                upQueue.insert(requestedFloor);    // Add to up queue if above the current floor
            }

            // Add to the appropriate queue (pickup or dropoff) based on the request
            if (isPickup) {
                pickupQueue.insert(requestedFloor);  // Add to pickup queue if it's a pickup
            } else {
                dropoffQueue.insert(requestedFloor);  // Add to dropoff queue if it's a dropoff
            }
        } 
        else if (receivedData[2] == 3) {
            // If packet type is 3, it's a ping response
            pingResponse = true;
        }
    }
}


//Main thread function to run the elevator
void ElevatorSubsystem::runElevator() {
    createThreads();
    while (true) {
        elevatorContext.performAction(); 

        //receiveFromScheduler(); // Ensure this is called to receive requests

        while (upQueue.empty() && downQueue.empty()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        while (elevatorContext.getCurrentElevatorState() == ElevatorStates::ARRIVED) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(elevatorStartTime));

        if (direction) {
            moveUp();
        } else {
            moveDown();
        }

        sendToScheduler();
    }
}

void ElevatorSubsystem::moveToFloor(int newFloor) {
    elevatorContext.setPrevElevatorState(elevatorContext.getCurrentElevatorState());
    elevatorContext.setElevatorState(ElevatorStates::MOVING);

    if (currentFloor != newFloor) {
        std::cout << "[ELEVATOR " << elevatorID << "]: Moving from " << currentFloor << " to " << newFloor << std::endl;
        while (currentFloor != newFloor) {
            std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime));
            currentFloor += direction == 1 ? 1 : -1;
        }
        elevatorContext.setCurrentFloor(newFloor); // Update state machine
        elevatorContext.setElevatorState(ElevatorStates::ARRIVED);
        std::cout << "[ELEVATOR " << elevatorID << "]: Elevator arrived at floor " << currentFloor << std::endl;
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(doorOpeningTime));

    elevatorContext.setPrevElevatorState(elevatorContext.getCurrentElevatorState());
    elevatorContext.setElevatorState(ElevatorStates::ARRIVED);

    // Mark doors as not open yet
    openResponse = false;

    std::vector<uint8_t> arrivalMsg;
    arrivalMsg.push_back(1);
    arrivalMsg.push_back(elevatorID);
    arrivalMsg.push_back(1);
    arrivalMsg.push_back(currentFloor);
    sendToSubsystem(SCHEDULEROFFSET + elevatorID, arrivalMsg);

    std::this_thread::sleep_for(std::chrono::seconds(10));

    openResponse = true;
}


void ElevatorSubsystem::moveUp() {
    // First handle pickups in the correct order
    while (!pickupQueue.empty()) {
        for (int floor : pickupQueue) {
            if (floor > currentFloor) {  // Only move to higher floors
                moveToFloor(floor);
                pickupQueue.erase(floor);  // Remove from pickup queue once processed
                capacity++;  // Increase capacity at pickup
                break;  // Prioritize one pickup at a time
            }
        }
    }

    // After handling pickups, process dropoffs
    while (!dropoffQueue.empty()) {
        int nextFloor = *dropoffQueue.begin();
        if (nextFloor > currentFloor) {  // Only move to higher floors
            moveToFloor(nextFloor);
            dropoffQueue.erase(nextFloor);  // Remove from dropoff queue once processed
            capacity--;  // Decrease capacity at dropoff
        }
    }

    // Now check the direction and move completed floors to the correct queue
    // Check if the elevator is already at its destination floor, then adjust the queue and direction
    upQueue.erase(currentFloor);
    completedFloors.insert(currentFloor);

    if (upQueue.empty() && !downQueue.empty()) {
        direction = false;  // Switch direction if no more requests in the upQueue
        elevatorContext.setDirection(0);  // Update direction in state machine
    }
}

void ElevatorSubsystem::moveDown() {
    // First handle pickups in the correct order
    while (!pickupQueue.empty()) {
        for (int floor : pickupQueue) {
            if (floor < currentFloor) {  // Only move to lower floors
                moveToFloor(floor);
                pickupQueue.erase(floor);  // Remove from pickup queue once processed
                capacity++;  // Increase capacity at pickup
                break;  // Prioritize one pickup at a time
            }
        }
    }

    // After handling pickups, process dropoffs
    while (!dropoffQueue.empty()) {
        int nextFloor = *dropoffQueue.rbegin();
        if (nextFloor < currentFloor) {  // Only move to lower floors
            moveToFloor(nextFloor);
            dropoffQueue.erase(nextFloor);  // Remove from dropoff queue once processed
            capacity--;  // Decrease capacity at dropoff
        }
    }

    // Now check the direction and move completed floors to the correct queue
    // Check if the elevator is already at its destination floor, then adjust the queue and direction
    downQueue.erase(currentFloor);
    completedFloors.insert(currentFloor);

    if (downQueue.empty() && !upQueue.empty()) {
        direction = true;  // Switch direction if no more requests in the downQueue
        elevatorContext.setDirection(1);  // Update direction in state machine
    }
}



void ElevatorSubsystem::openDoors() {
    std::cout << "[ELEVATOR " << elevatorID << "]: Opening doors on floor " << currentFloor << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(5)); //Simulate door opening
    capacity += pickupQueue.count(currentFloor) ? 1 : -1;
    std::cout << "[ELEVATOR " << elevatorID << "]: Closing doors on floor " << currentFloor << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(5)); //Simulate door closing
}

//getters for the test files
std::set<int> ElevatorSubsystem::getUpQueue() {
    return upQueue;
}

std::set<int> ElevatorSubsystem::getDownQueue() {
    return downQueue;
}

int ElevatorSubsystem::getCurrentFloor() const {
    return currentFloor;
}

int ElevatorSubsystem::getElevatorID() const {
    return elevatorID;
}

std::set<int> ElevatorSubsystem::getCompletedFloors() {
    return completedFloors;
}

bool ElevatorSubsystem::getDirection() {
    return direction;
}

ElevatorStates ElevatorContext::getCurrentState() {
    return currentElevatorState;
}

//setters for test files
void ElevatorSubsystem::setCompletedFloors(std::set<int> completed) {
    completedFloors = completed;
}


