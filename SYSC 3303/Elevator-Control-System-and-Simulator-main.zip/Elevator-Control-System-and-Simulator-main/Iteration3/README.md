## Elevator-Control-System-and-Simulator
Term project for SYSC3303 Iteration 3:
- Andrew Rivera 101192264 
- Kyle Mathias 101266139
- Ryan Page 101268082
- Kael Lascelle 101269383
- Noah Oatley 101189707

## Iteration 2 Group Assignments
### UML Diagrams
Kael and Noah

### Testing Code
Ryan, Kael and Noah

### ElevatorSystem Code
Schedulers - Noah, Kyle and Andrew

Elevators - Andrew and Kyle

Floors - Kyle and Andrew

### New Files for Iteration 3:
**InetHelpers.cpp** - Helper functions that use Datagram methods for sending and receiving packets.

**InetHelpers.hpp** - Header file for InetHelpers.cpp.

**Datagram.hpp** - Header file provided Prof. Franks for handling sockets and packets

### Running the ElevatorSystem.cpp File
1. Press Ctrl + Alt + T to open the terminal.
2. Navigate to Your Project Directory (using cd) 
3. Make run_ElevatorSystem.sh Executable By typing this into the Terminal
    - chmod +x run_ElevatorSystem.sh
4. Run the File By writing this into the Terminal
    - ./run_ElevatorSystem.sh
5. If errors are raised indicating the the command was not found
    - Run this command: sudo apt-get install xterm
    - Then run ./run_ElevatorSystem.sh again.

### Running the Testing.cpp File
1. Press Ctrl + Alt + T to open the terminal.
2. Navigate to Your Project Directory (using cd) 
3. Make run_Testing.sh Executable By typing this into the Terminal
    - chmod +x run_Testing.sh
4. Run the File By writing this into the Terminal
    - ./run_Testing.sh
