#ifndef SCHEDULER_SYSTEM_HPP
#define SCHEDULER_SYSTEM_HPP

#include "Globals.hpp"
#include "ElevatorSystem.hpp"
#include "SchedulerStatemachine.hpp"

class SchedulerSystem {
private:
    std::set<int> RequestedFloors;
    std::set<int> completedFloors;
    std::queue<struct RequestStructure> scheduledRequests;
    

public:
    SchedulerContext schedulerContext;
    void takeRequests();
    void sendRequests();
    void getCompleted();
    void notifyFloors();
    void runScheduler();
    std::queue<struct RequestStructure> getScheduledRequests();
    std::set<int> getRequestedFloors();
    std::set<int> getCompletedFloors();
    std::set<int> getFinishedFloors();
    void setScheduledRequests(std::queue<struct RequestStructure> sch);
    void setRequestedFloors(std::set<int> req);
    void setCompletedFloors(std::set<int> com);
    
};

#endif