#ifndef ELEVATORSTATEMACHINE_HPP 
#define ELEVATORSTATEMACHINE_HPP
#include <iostream>
#include <thread>
#include <chrono>
#include <queue>
#include <vector>

enum class ElevatorStates {STATIONARY, MOVING, ARRIVED};

class ElevatorContext {
public:
    ElevatorContext();

    void performAction(); //Perform the current state's action.
    void setElevatorState(ElevatorStates newState);
    void setPrevElevatorState(ElevatorStates prevState);
    ElevatorStates getPrevElevatorState();
    ElevatorStates getCurrentElevatorState();
    int getCurrentFloor();       // Gets from queue
    int getDestination (); //Gets from queue
    int getDirection (); //Gets from queue
    const int getQueueSize ();
    bool getStatus (); //Determine if Elevator = Ready.
    void addPacketRequest (std::vector<int> data); //Add packet request to queue.
    ElevatorStates getState(); //Get current state.

private:
    ElevatorStates currentElevatorState; //Current state
    ElevatorStates prevElevatorState; 
    std::queue<std::vector<int>> requestQueue;
    std::vector<int> packet;
    int currentFloor;
    int destination;
    int direction;
    bool ready;


    void handleStationary();
    void handleMoving();
    void handleArrived();
};
#endif