#include "ElevatorSubsystem.hpp"
#include "FloorSubsystem.hpp"
#include "SchedulerSystem.hpp"
#include "Globals.hpp"

int main() {
    FloorSubsystem floor("input.txt"); 
    SchedulerSystem scheduler;
    ElevatorSubsystem elevator;

    std::thread floorThread(&FloorSubsystem::runFloor, &floor);
    std::thread schedulerThread(&SchedulerSystem::runScheduler, &scheduler);
    std::thread elevatorThread(&ElevatorSubsystem::runElevator, &elevator);

    floorThread.join();
    schedulerThread.join();
    elevatorThread.join();

    std::cout << "main end";

    return 0;
}
