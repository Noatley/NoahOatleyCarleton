#include "SchedulerStatemachine.hpp"

SchedulerContext::SchedulerContext() : prevSchedulerState(SchedulerStates::LISTENING), currentSchedulerState(SchedulerStates::LISTENING), floorReady(false), elevatorReady(false){
    //Starts in LISTENING state, and intializes attributes to default values.
}

const int SchedulerContext::requestQueueSize() {
    return requestQueue.size();
}

const int SchedulerContext::elevatorQueueSize() {
    return elevatorQueue.size();
}

void SchedulerContext::getRequest (std::vector<int> data){
    requestQueue.push(data); //Push the packet into a queue of requested packets?
    std::cout << "Packet request added to queue" << std::endl;
}

void SchedulerContext::setSchedulerState(SchedulerStates nextState){
    prevSchedulerState = currentSchedulerState;
    currentSchedulerState = nextState;
}

SchedulerStates SchedulerContext::getCurrentSchedulerState() {
    return currentSchedulerState;
}

SchedulerStates SchedulerContext::getPrevSchedulerState() {
    return prevSchedulerState;
}

void SchedulerContext::performAction() {
    switch (currentSchedulerState){
        case SchedulerStates::LISTENING:
            handleListening();
            break;
        case SchedulerStates::SCHEDULING:
            handleScheduling();
            break;
        case SchedulerStates::TRANSMITTING:
            handleTransmitting();
            break;

        case SchedulerStates::OPENING:
            handleOpening();
            break;
    }
}

void SchedulerContext::handleListening() {
    if(!requestQueue.empty()) { // If there are requests in the queue, move to SCHEDULING
        SchedulerContext::setSchedulerState(SchedulerStates::SCHEDULING);
    }
}

void SchedulerContext::handleScheduling() {
    while(!requestQueue.empty()) { // Add items to elevator's queue
        elevatorQueue.push(requestQueue.front());
        requestQueue.pop();
    }
    // Once all items are scheduled, transmit
    SchedulerContext::setSchedulerState(SchedulerStates::TRANSMITTING);
}

void SchedulerContext::handleTransmitting() {
    SchedulerContext::setSchedulerState(SchedulerStates::OPENING);
}

void SchedulerContext::handleOpening() { // Simulate signalling to open doors when implemented in later iterations
    while(!elevatorQueue.empty()) {
        elevatorQueue.pop();
    }
    SchedulerContext::setSchedulerState(SchedulerStates::LISTENING);
}
