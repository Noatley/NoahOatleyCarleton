#ifndef ELEVATOR_SUBSYSTEM_HPP
#define ELEVATOR_SUBSYSTEM_HPP

#include "Globals.hpp"
#include "ElevatorSystem.hpp"
#include "ElevatorStatemachine.hpp"

class ElevatorSubsystem {
private:
    std::set<int> upQueue;
    std::set<int> downQueue;
    std::set<int> completedFloors;
    int currentFloor;
    bool direction;

public:
    ElevatorContext elevatorContext;
    ElevatorSubsystem();
    void sendToScheduler();
    void receiveFromScheduler();
    void runElevator();
    std::set<int> getUpQueue();
    std::set<int> getDownQueue();
    int getCurrentFloor() const;
    std::set<int> getCompletedFloors();
    void setCompletedFloors(std::set<int> completed);
    void moveUp();
    void moveDown();

private:
    void moveToFloor(int newFloor);
};

#endif