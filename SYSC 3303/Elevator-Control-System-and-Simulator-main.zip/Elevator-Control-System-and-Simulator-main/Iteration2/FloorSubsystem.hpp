#ifndef FLOOR_SUBSYSTEM_HPP
#define FLOOR_SUBSYSTEM_HPP

#include "Globals.hpp"
#include "ElevatorSystem.hpp"

class FloorSubsystem {
private:
    std::vector<std::queue<Person>> floors;
    std::priority_queue<RequestStructure> inputs;
    bool invalidInput = false;

public:
    FloorSubsystem(std::string fileName);
    void sendToScheduler();
    void receiveFromScheduler();
    void runFloor();
    std::priority_queue<RequestStructure> getInputs();
    void setInputs(std::priority_queue<RequestStructure> in);
    bool getInvalidInput();



private:
    void parseFile(std::ifstream& inputFileStream);
    std::chrono::milliseconds chronoConversion(std::string time);
};

#endif