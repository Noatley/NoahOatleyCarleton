#include "SchedulerSystem.hpp"
#include "SchedulerStatemachine.hpp"

//FLOOR->SCHEDULER
void SchedulerSystem::takeRequests() {
    schedulerContext.setSchedulerState(SchedulerStates::LISTENING);
    //schedulerContext.performAction();
    while (!requests.empty()) {
        scheduledRequests.push(requests.front());
        requests.pop();
    }
}

//SCHEDULER->ELEVATOR
void SchedulerSystem::sendRequests() {
    schedulerContext.setSchedulerState(SchedulerStates::TRANSMITTING);
    //schedulerContext.performAction();
    while (!scheduledRequests.empty()) {
        elevatorQueue.push(scheduledRequests.front());
        scheduledRequests.pop();
    }
}

//ELEVATOR->SCHEDULER
void SchedulerSystem::getCompleted() {
    schedulerContext.setSchedulerState(SchedulerStates::SCHEDULING);
    //schedulerContext.performAction();
    while (!pickups.empty()) {
        int value = *pickups.begin();
        completedFloors.insert(value);
        pickups.erase(value);
    }
}

//SCHEDULER->FLOOR
void SchedulerSystem::notifyFloors() {
    schedulerContext.setSchedulerState(SchedulerStates::OPENING);
    //schedulerContext.performAction();
    while (!completedFloors.empty()) {
        int value = *completedFloors.begin();
        finishedFloors.insert(value);
        completedFloors.erase(value);
    }
}

void SchedulerSystem::runScheduler() {
    while (true) {
        takeRequests();  
        sendRequests();
        getCompleted(); 
        notifyFloors();  

        std::this_thread::sleep_for(std::chrono::milliseconds(100)); 
    }
}

//getters
std::queue<struct RequestStructure> SchedulerSystem::getScheduledRequests () {
    return scheduledRequests;
}

std::set<int> SchedulerSystem::getRequestedFloors () {
    return RequestedFloors;
}

std::set<int> SchedulerSystem::getCompletedFloors () {
    return completedFloors;
}

std::set<int> SchedulerSystem::getFinishedFloors () {
    return finishedFloors;
}

//setters
void SchedulerSystem::setScheduledRequests (std::queue<struct RequestStructure> sch) {
    scheduledRequests = sch;
}

void SchedulerSystem::setRequestedFloors (std::set<int> req) {
    RequestedFloors = req;
}

void SchedulerSystem::setCompletedFloors (std::set<int> com) {
    completedFloors = com;
}


