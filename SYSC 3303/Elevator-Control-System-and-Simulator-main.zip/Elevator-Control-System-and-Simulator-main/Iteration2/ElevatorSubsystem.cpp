#include "ElevatorSubsystem.hpp"

ElevatorSubsystem::ElevatorSubsystem() : currentFloor(1), direction(true) {}

//ELEVATOR->SCHEDULER
void ElevatorSubsystem::sendToScheduler() {
    std::unique_lock<std::mutex> lock(pickLock);

    if (pickCond.wait_until(lock, std::chrono::steady_clock::now() + std::chrono::milliseconds(500), [this] { return !completedFloors.empty(); })) {
        std::cout << "[Elevator Subsystem]: Sending completed floors to scheduler: " << completedFloors.size() << " floors to process." << std::endl;
        while (!completedFloors.empty()) {
            int value = *completedFloors.begin();
            pickups.insert(value);
            completedFloors.erase(value);
        }
        std::cout << "[Elevator Subsystem]: Finished sending completed floors to scheduler." << std::endl;
        pickCond.notify_all();
    } else {
        std::cout << "[Elevator Subsystem]: No completed floors to send to scheduler." << std::endl;
    }

    elevatorContext.setPrevElevatorState(elevatorContext.getCurrentElevatorState());
    elevatorContext.setElevatorState(ElevatorStates::STATIONARY);
}

//SCHEDULER->ELEVATOR
void ElevatorSubsystem::receiveFromScheduler() {
    std::unique_lock<std::mutex> lock(elevatorLock);

    if (eleCond.wait_until(lock, std::chrono::steady_clock::now() + std::chrono::milliseconds(500), [this] { return !elevatorQueue.empty(); })) {
        std::cout << "[Elevator Subsystem]: Receiving requests from scheduler: " << elevatorQueue.size() << " requests to process." << std::endl;
        while (!elevatorQueue.empty()) {
            RequestStructure request = elevatorQueue.front();
            elevatorQueue.pop();

            if (request.direction) {
                upQueue.insert(request.originFloor);
                upQueue.insert(request.destination);
            } else {
                downQueue.insert(request.originFloor);
                downQueue.insert(request.destination);
            }
        }
        std::cout << "[Elevator Subsystem]: Finished receiving requests from scheduler." << std::endl;
        eleCond.notify_all();
    } else {
        std::cout << "[Elevator Subsystem]: No requests to receive from scheduler." << std::endl;
    }
}

//Main thread function to run the elevator
void ElevatorSubsystem::runElevator() {
    while (true) {
        std::cout << "[Elevator Subsystem]: Running elevator..." << std::endl;
        elevatorContext.performAction(); 

        receiveFromScheduler(); // Ensure this is called to receive requests

        if (upQueue.empty() && downQueue.empty()) {
            std::unique_lock<std::mutex> lock(elevatorLock);
            std::cout << "[Elevator Subsystem]: Elevator waiting for requests..." << std::endl;
            eleCond.wait(lock, [this] { return !upQueue.empty() || !downQueue.empty(); });
        }

        if (direction) {
            moveUp();
        } else {
            moveDown();
        }
        sendToScheduler(); 
    }
}

void ElevatorSubsystem::moveToFloor(int newFloor) {
    elevatorContext.setPrevElevatorState(elevatorContext.getCurrentElevatorState());
    elevatorContext.setElevatorState(ElevatorStates::MOVING);
    assert(elevatorContext.getCurrentElevatorState() == ElevatorStates::MOVING);
    if (currentFloor != newFloor) {
        std::cout << "[Elevator Subsystem]: Moving from " << currentFloor << " to " << newFloor << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(elevatorTravelTime));
        currentFloor = newFloor;
        std::cout << "[Elevator Subsystem]: Elevator arrived at floor " << currentFloor << std::endl;
    }
    elevatorContext.setPrevElevatorState(elevatorContext.getCurrentElevatorState());
    elevatorContext.setElevatorState(ElevatorStates::ARRIVED);
    assert(elevatorContext.getCurrentElevatorState() == ElevatorStates::ARRIVED);
}

void ElevatorSubsystem::moveUp() {
    while (!upQueue.empty()) {
        int nextFloor = *upQueue.begin();
        if (nextFloor > currentFloor) {
            moveToFloor(nextFloor);
            upQueue.erase(nextFloor);
            completedFloors.insert(nextFloor);
        } else if (nextFloor == currentFloor) {
            std::cout << "[Elevator Subsystem]: Elevator is already on floor " << currentFloor << ". Handling request." << std::endl;
            upQueue.erase(nextFloor);
            completedFloors.insert(nextFloor);
        } else {
            break;
        }
    }

    if (upQueue.empty() && !downQueue.empty()) {
        direction = false;
    }
}

void ElevatorSubsystem::moveDown() {
    while (!downQueue.empty()) {
        int nextFloor = *downQueue.rbegin();
        if (nextFloor < currentFloor) {
            moveToFloor(nextFloor);
            downQueue.erase(nextFloor);
            completedFloors.insert(nextFloor);
        } else if (nextFloor == currentFloor) {
            std::cout << "[Elevator Subsystem]: Elevator is already on floor " << currentFloor << ". Handling request." << std::endl;
            downQueue.erase(nextFloor);
            completedFloors.insert(nextFloor);
        } else {
            break;
        }
    }

    if (downQueue.empty() && !upQueue.empty()) {
        direction = true;
    }
}
//getters for the test files
std::set<int> ElevatorSubsystem::getUpQueue() {
    return upQueue;
}

std::set<int> ElevatorSubsystem::getDownQueue() {
    return downQueue;
}

int ElevatorSubsystem::getCurrentFloor() const {
    return currentFloor;
}

std::set<int> ElevatorSubsystem::getCompletedFloors() {
    return completedFloors;
}

//setters for test files
void ElevatorSubsystem::setCompletedFloors(std::set<int> completed) {
    completedFloors = completed;
}

