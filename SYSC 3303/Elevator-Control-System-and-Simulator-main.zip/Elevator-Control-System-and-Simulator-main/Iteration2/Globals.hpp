#ifndef GLOBALS_HPP
#define GLOBALS_HPP

#include <queue>
#include <set>
#include <mutex>
#include <condition_variable>
#include "ElevatorSystem.hpp" // Include the main header for struct definitions

// Declare global variables
extern std::queue<struct RequestStructure> requests; // Requests from floor to scheduler
extern std::queue<struct RequestStructure> elevatorQueue; // Requests from scheduler to elevator
extern std::set<int> pickups; // Elevator notifies scheduler of completed floors
extern std::set<int> finishedFloors; // Scheduler notifies floor to empty its queue

// Declare global mutexes and condition variables
extern std::mutex schedulerLock;
extern std::condition_variable_any cond;
extern std::mutex elevatorLock;
extern std::condition_variable_any eleCond;
extern std::mutex pickLock;
extern std::condition_variable pickCond;

#endif