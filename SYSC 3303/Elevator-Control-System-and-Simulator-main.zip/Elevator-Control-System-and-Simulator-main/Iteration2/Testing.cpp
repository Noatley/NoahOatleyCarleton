/**
 * Testing.cpp
 * This file contains the test cases for the Elevator System.
 * @author Ryan Page
 * @version 1.0
 * @date 2021-11-01
 */
#include "ElevatorStatemachine.cpp"
#include "ElevatorSubsystem.cpp"
#include "FloorSubsystem.cpp"
#include "SchedulerSystem.cpp"
#include "SchedulerStatemachine.cpp"
#include "Globals.cpp"
#include <iostream>
#include <cassert>

bool testElevatorSubsystemInitialization() {
    ElevatorSubsystem elevatorSubsystem;
    assert(elevatorSubsystem.getCurrentFloor() == 1);
    assert(elevatorSubsystem.getCompletedFloors().size() != 1);
    assert(elevatorSubsystem.getDownQueue().size() == 0);
    assert(elevatorSubsystem.getUpQueue().size() == 0);
    assert(elevatorSubsystem.elevatorContext.getQueueSize() == 0);
    assert(elevatorSubsystem.elevatorContext.getState() == ElevatorStates::STATIONARY);
    assert(elevatorSubsystem.elevatorContext.getStatus() == false);
    return true;
    return true;
}

bool testSchedulerSystemInitialization() {
    SchedulerSystem schedulerSystem;
    assert(schedulerSystem.getRequestedFloors().size() == 0);
    assert(schedulerSystem.getScheduledRequests().size() == 0);
    return true;
}

bool testGoingToInvalidFloor_FromInputFile(){
    FloorSubsystem floorSubsystem1("test1.txt");
    assert(floorSubsystem1.getInvalidInput() == true);
    FloorSubsystem floorSubsystem2("test2.txt");
    assert(floorSubsystem2.getInvalidInput() == true);
    FloorSubsystem floorSubsystem3("test5.txt");
    assert(floorSubsystem3.getInvalidInput() == true);
    FloorSubsystem floorSubsystem4("test6.txt");
    assert(floorSubsystem4.getInvalidInput() == true);
    return true;
}

bool SendingRequestToSchedulerThenElevator_AndBack(){
    FloorSubsystem floorSubsystem4("test3.txt");
    SchedulerSystem schedulerSystem4;
    ElevatorSubsystem elevatorSubsystem4;
    floorSubsystem4.sendToScheduler();
    schedulerSystem4.takeRequests();
    assert(schedulerSystem4.schedulerContext.getCurrentSchedulerState() == SchedulerStates::LISTENING);
    assert(schedulerSystem4.getScheduledRequests().size() == 3);
    schedulerSystem4.sendRequests();
    assert(schedulerSystem4.schedulerContext.getCurrentSchedulerState() == SchedulerStates::TRANSMITTING);
    elevatorSubsystem4.receiveFromScheduler();
    assert(elevatorSubsystem4.getUpQueue().size() == 3);
    assert(elevatorSubsystem4.getDownQueue().size() == 2);
    assert(elevatorSubsystem4.elevatorContext.getCurrentElevatorState() == ElevatorStates::STATIONARY);
    elevatorSubsystem4.moveUp();
    assert(elevatorSubsystem4.elevatorContext.getPrevElevatorState() == ElevatorStates::MOVING);
    assert(elevatorSubsystem4.elevatorContext.getCurrentElevatorState() == ElevatorStates::ARRIVED);
    elevatorSubsystem4.sendToScheduler();
    assert(elevatorSubsystem4.elevatorContext.getPrevElevatorState() == ElevatorStates::ARRIVED);
    assert(elevatorSubsystem4.elevatorContext.getCurrentElevatorState() == ElevatorStates::STATIONARY);
    schedulerSystem4.getCompleted();
    assert(schedulerSystem4.schedulerContext.getCurrentSchedulerState() == SchedulerStates::SCHEDULING);
    assert(schedulerSystem4.getCompletedFloors().size() == 3);
    schedulerSystem4.notifyFloors();
    assert(schedulerSystem4.schedulerContext.getCurrentSchedulerState() == SchedulerStates::OPENING);
    assert(schedulerSystem4.getCompletedFloors().size() == 0);
    assert(schedulerSystem4.getFinishedFloors().size() == 3);
    floorSubsystem4.receiveFromScheduler();
    assert(schedulerSystem4.getFinishedFloors().size() == 0);
    elevatorSubsystem4.moveDown();
    assert(elevatorSubsystem4.elevatorContext.getPrevElevatorState() == ElevatorStates::MOVING);
    assert(elevatorSubsystem4.elevatorContext.getCurrentElevatorState() == ElevatorStates::ARRIVED);
    elevatorSubsystem4.sendToScheduler();
    assert(elevatorSubsystem4.elevatorContext.getPrevElevatorState() == ElevatorStates::ARRIVED);
    assert(elevatorSubsystem4.elevatorContext.getCurrentElevatorState() == ElevatorStates::STATIONARY);
    schedulerSystem4.getCompleted();
    assert(schedulerSystem4.schedulerContext.getCurrentSchedulerState() == SchedulerStates::SCHEDULING);
    assert(schedulerSystem4.getCompletedFloors().size() == 2);
    schedulerSystem4.notifyFloors();
    assert(schedulerSystem4.schedulerContext.getCurrentSchedulerState() == SchedulerStates::OPENING);
    assert(schedulerSystem4.getCompletedFloors().size() == 0);
    assert(schedulerSystem4.getFinishedFloors().size() == 2);
    floorSubsystem4.receiveFromScheduler();
    assert(schedulerSystem4.getFinishedFloors().size() == 0);

    return true;
}

bool TestMovingFloors(){
    FloorSubsystem floorSubsystem5("test4.txt");
    SchedulerSystem schedulerSystem5;
    ElevatorSubsystem elevatorSubsystem5;
    floorSubsystem5.sendToScheduler();
    schedulerSystem5.takeRequests();
    assert(schedulerSystem5.schedulerContext.getCurrentSchedulerState() == SchedulerStates::LISTENING);
    schedulerSystem5.sendRequests();
    assert(schedulerSystem5.schedulerContext.getCurrentSchedulerState() == SchedulerStates::TRANSMITTING);
    elevatorSubsystem5.receiveFromScheduler();
    assert(elevatorSubsystem5.elevatorContext.getCurrentElevatorState() == ElevatorStates::STATIONARY);
    elevatorSubsystem5.moveUp();
    assert(elevatorSubsystem5.elevatorContext.getPrevElevatorState() == ElevatorStates::MOVING);
    assert(elevatorSubsystem5.elevatorContext.getCurrentElevatorState() == ElevatorStates::ARRIVED);
    assert(elevatorSubsystem5.getCurrentFloor() == 15);
    elevatorSubsystem5.moveDown();
    assert(elevatorSubsystem5.getCurrentFloor() == 3);
    assert(elevatorSubsystem5.elevatorContext.getPrevElevatorState() == ElevatorStates::MOVING);
    assert(elevatorSubsystem5.elevatorContext.getCurrentElevatorState() == ElevatorStates::ARRIVED);
    return true;
}

int main() {
    bool allTestsPassed = true;
    bool Test1 = testElevatorSubsystemInitialization();
    bool Test2 = testSchedulerSystemInitialization();
    bool Test3 = testGoingToInvalidFloor_FromInputFile();
    bool Test4 = TestMovingFloors();
    bool Test5 = SendingRequestToSchedulerThenElevator_AndBack();
    
    std::cout << "_______________________________________________________________\n\n";
    std::cout << "Elevator System Testing (1 = Passed, 0 = Failed)" << std::endl;
    std::cout << "_______________________________________________________________\n";
    std::cout << "Test 1: ElevatorSubsystem Initialization: " << Test1 << std::endl;
    std::cout << "Test 2: SchedulerSystem Initialization: " << Test2 << std::endl;
    std::cout << "Test 3: Going to Invalid Floor from Input File: " << Test3 << std::endl;  
    std::cout << "Test 4: Moving Floors: " << Test4 << std::endl;
    std::cout << "Test 5: Sending Request to Scheduler then Elevator and Back: " << Test5 << std::endl;

    allTestsPassed = Test1 && Test2 && Test3 && Test4 && Test5;

     // Print the overall results
     std::cout << "\nOverall Test Results: " << (allTestsPassed ? "All Tests Passed" : "Some Tests Failed") << "\n";
     std::cout << "_______________________________________________________________\n";
     return 0;
}