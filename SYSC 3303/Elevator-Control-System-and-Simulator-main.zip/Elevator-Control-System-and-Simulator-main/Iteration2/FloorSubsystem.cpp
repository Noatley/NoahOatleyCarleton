#include "FloorSubsystem.hpp"

FloorSubsystem::FloorSubsystem(std::string fileName) { //constructor needs to grab input file data and store it to create inputs
    floors.resize(numFloors); //resize the floors vector to the max number of floors
    std::ifstream inputFile(fileName); //initialize ifstream for input file
    assert(inputFile.is_open()); //make sure file exists
    parseFile(inputFile); //run the parse method to interpret file contents
    inputFile.close(); //close file
}

//FLOOR->SCHEDULER
void FloorSubsystem::sendToScheduler() { //send floorrequests to scheduler
    std::unique_lock<std::mutex> lock(schedulerLock); //shares mutex schedulerLock

    if (cond.wait_until(lock, std::chrono::steady_clock::now() + std::chrono::milliseconds(500), [this] { return !inputs.empty(); })) { //wait until theres requests in the internal input queue, or timeout after 500ms
        std::cout << "[Floor Subsystem]: Sending requests to scheduler: " << inputs.size() << " requests to process." << std::endl;
        while (!inputs.empty()) { //loop until internal inputs queue empty
            requests.push(inputs.top()); //dump local inputs to global requests
            Person person = Person(inputs.top().destination, inputs.top().direction); //create a new Person object 
            floors[inputs.top().originFloor].push(person); //add the person to the floor
            inputs.pop(); 
        }
        std::cout << "[Floor Subsystem]: Finished sending requests to scheduler." << std::endl;
        cond.notify_all(); //unlock
    } else {
        std::cout << "[Floor Subsystem]: No requests to send to scheduler." << std::endl;
    }
}

//SCHEDULER->FLOOR
void FloorSubsystem::receiveFromScheduler() { 
    std::unique_lock<std::mutex> lock(pickLock); //shares mutex pickLock

    if (pickCond.wait_until(lock, std::chrono::steady_clock::now() + std::chrono::milliseconds(500), [this] { return !finishedFloors.empty(); })) { //wait until theres finished floors globally or timeout 500ms
        std::cout << "[Floor Subsystem]: Receiving completed floors from scheduler: " << finishedFloors.size() << " floors to process." << std::endl;
        while (!finishedFloors.empty()) { //iterate through each finished floor
            int value = *finishedFloors.begin();
            while (!floors[value - 1].empty()) { //value - 1 because vector starts floor 1 from index 0 so index = floor - 1
                floors[value - 1].pop(); //remove all people at that floor (theyre in the elevator or got off at that floor already)
            }
            finishedFloors.erase(value); 
        }
        std::cout << "[Floor Subsystem]: Finished receiving completed floors from scheduler." << std::endl;
        pickCond.notify_all(); //unlock
    } else {
        std::cout << "[Floor Subsystem]: No completed floors to receive from scheduler." << std::endl;
    }
}

//main thread function to run the floor
void FloorSubsystem::runFloor() {
    while (true) {
        sendToScheduler();   //send floor requests to Scheduler
        receiveFromScheduler(); //receive completed floors
        std::this_thread::sleep_for(std::chrono::milliseconds(100)); 
    }
}

//getters
std::priority_queue<RequestStructure> FloorSubsystem::getInputs() {
    return inputs;
}

//setters
void FloorSubsystem::setInputs(std::priority_queue<RequestStructure> in) {
    inputs = in;
}

void FloorSubsystem::parseFile(std::ifstream& inputFileStream) { //function for reading input filestream from file and extracting its contents to a RequestStructure
    std::string line; //string to extract each line

    while(std::getline(inputFileStream, line)) {
        std::stringstream ss(line); //create stringstream from line
        std::string timeStr, dirStr; //variables to extract information from
        std::chrono::milliseconds time;
        signed curr, dest;
        bool dir;
            ss >> timeStr >> curr >> dirStr >> dest; //if the input is formatted properly, all variables should be initialized properly

        if(dest < 1 || dest > numFloors || curr < 1 || curr > numFloors){ //check if the floor is valid{
            invalidInput = true;
        }else{

            time = chronoConversion(timeStr); //convert time to ms
    
            if (dirStr == "Up" || dirStr == "up") { //get directions from the string
                dir = true;
            }
            else if (dirStr == "Down" || dirStr == "down") {
                dir = false;
            }
            else {
                throw std::invalid_argument("Wrong direction");
            }
    
            RequestStructure input(time, curr, dest, dir); //create request structure with these variables
    
            inputs.push(input); //add requeststructure to internal inputs
    
            //debug just to see data from input
            std::cout << "[Floor Subsystem]: Parsed request: Current Floor: " << input.originFloor << ", Direction: " << input.direction << ", Destination Floor: " << input.destination << std::endl;    
        }
    }
}

std::chrono::milliseconds FloorSubsystem::chronoConversion(std::string time) { //function to take entire time string and convert to ms
    int hours, minutes, seconds, milliseconds;
    char colon, period;

    std::istringstream timeStream(time); //create stringstream from time
    timeStream >> hours >> colon >> minutes >> colon >> seconds >> period >> milliseconds; //if formatted correctly, should fit into all variables

    return std::chrono::hours(hours) + std::chrono::minutes(minutes) + std::chrono::seconds(seconds) + std::chrono::milliseconds(milliseconds); //add up converted times and return
}

bool FloorSubsystem::getInvalidInput() {
    return invalidInput;
}
