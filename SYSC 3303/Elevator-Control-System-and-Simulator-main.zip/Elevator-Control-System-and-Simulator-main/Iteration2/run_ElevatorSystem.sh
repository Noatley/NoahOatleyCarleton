#!/bin/bash

# Remove old executable
rm -f ElevatorSystem

# Compile the C++ files with pthread support
g++ ElevatorSystem.cpp FloorSubsystem.cpp ElevatorSubsystem.cpp SchedulerSystem.cpp Globals.cpp ElevatorStatemachine.cpp SchedulerStatemachine.cpp -o ElevatorSystem -pthread

# Check if compilation was successful
if [ $? -eq 0 ]; then
    echo "Compilation successful. Running the program..."
    ./ElevatorSystem
else
    echo "Compilation failed."
fi